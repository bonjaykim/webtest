import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import type { Chipset } from "@/lib/sample-data"
import { Badge } from "@/components/ui/badge"

interface ChipsetDetailViewProps {
  chipset: Chipset
}

export function ChipsetDetailView({ chipset }: ChipsetDetailViewProps) {
  const formatKey = (key: string) => {
    return key
      .replace(/([A-Z])/g, " $1")
      .replace(/^./, (str) => str.toUpperCase())
      .trim()
  }

  const formatValue = (key: string, value: any) => {
    if (value === undefined) return "—"

    if (Array.isArray(value)) {
      return (
        <div className="flex flex-wrap gap-1">
          {value.map((item, i) => (
            <Badge key={i} variant="outline">
              {item}
            </Badge>
          ))}
        </div>
      )
    }

    if (typeof value === "number") {
      if (key === "clockSpeed") return `${value} GHz`
      if (key === "tdp") return `${value} W`
      if (key === "transistorCount") return `${value} billion`
      if (key === "manufacturingProcess") return `${value} nm`
      if (key === "memoryBandwidth") return `${value} GB/s`
      if (key === "cacheSize") return `${value} MB`
      if (key === "performanceScore" || key === "energyEfficiency") {
        const color =
          value >= 90
            ? "bg-green-100 text-green-800"
            : value >= 80
              ? "bg-blue-100 text-blue-800"
              : value >= 70
                ? "bg-yellow-100 text-yellow-800"
                : "bg-red-100 text-red-800"
        return (
          <Badge className={color} variant="outline">
            {value}/100
          </Badge>
        )
      }
      if (key === "neuralEnginePerformance") return `${value} TOPS`
    }

    return value.toString()
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row gap-4 items-start">
        <Card className="w-full md:w-2/3">
          <CardHeader>
            <CardTitle>Specifications</CardTitle>
            <CardDescription>Technical details for {chipset.name}</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {Object.entries(chipset.info).map(([key, value]) => (
                <div key={key} className="flex flex-col space-y-1">
                  <span className="text-sm font-medium text-muted-foreground">{formatKey(key)}</span>
                  <span className="font-medium">{formatValue(key, value)}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="w-full md:w-1/3">
          <CardHeader>
            <CardTitle>Overview</CardTitle>
            <CardDescription>Summary information</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <div className="text-sm font-medium text-muted-foreground">Type</div>
                <div className="font-medium">{chipset.kind}</div>
              </div>

              <div>
                <div className="text-sm font-medium text-muted-foreground">ID</div>
                <div className="font-medium">{chipset.id}</div>
              </div>

              {chipset.info.releaseYear && (
                <div>
                  <div className="text-sm font-medium text-muted-foreground">Released</div>
                  <div className="font-medium">{chipset.info.releaseYear}</div>
                </div>
              )}

              {chipset.info.architecture && (
                <div>
                  <div className="text-sm font-medium text-muted-foreground">Architecture</div>
                  <div className="font-medium">{chipset.info.architecture}</div>
                </div>
              )}

              {chipset.info.performanceScore && (
                <div>
                  <div className="text-sm font-medium text-muted-foreground">Performance Score</div>
                  <div className="font-medium">{formatValue("performanceScore", chipset.info.performanceScore)}</div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
