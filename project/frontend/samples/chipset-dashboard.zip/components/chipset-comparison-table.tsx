import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import type { Chipset } from "@/lib/sample-data"
import { HelpCircle } from "lucide-react"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"

interface ChipsetComparisonTableProps {
  chipsets: Chipset[]
}

export function ChipsetComparisonTable({ chipsets }: ChipsetComparisonTableProps) {
  if (chipsets.length === 0) {
    return <div>Select chipsets to compare</div>
  }

  // Get all unique component keys from all chipsets
  const allComponentKeys = new Set<string>()
  chipsets.forEach((chipset) => {
    Object.keys(chipset.info).forEach((key) => allComponentKeys.add(key))
  })

  const formatValue = (key: string, value: any) => {
    if (value === undefined) return "—"

    if (Array.isArray(value)) {
      return value.join(", ")
    }

    if (typeof value === "number") {
      if (key === "clockSpeed") return `${value} GHz`
      if (key === "tdp") return `${value} W`
      if (key === "transistorCount") return `${value} billion`
      if (key === "manufacturingProcess") return `${value} nm`
      if (key === "memoryBandwidth") return `${value} GB/s`
      if (key === "cacheSize") return `${value} MB`
      if (key === "performanceScore" || key === "energyEfficiency") return `${value}/100`
      if (key === "neuralEnginePerformance") return `${value} TOPS`
    }

    return value.toString()
  }

  const formatKey = (key: string) => {
    return key
      .replace(/([A-Z])/g, " $1")
      .replace(/^./, (str) => str.toUpperCase())
      .trim()
  }

  const getTooltipForKey = (key: string) => {
    const tooltips: Record<string, string> = {
      // CPU 관련
      clockSpeed: "최대 클럭 주파수 (GHz). 높을수록 연산 속도가 빠릅니다.",
      cores: "프로세서 코어 수. 많을수록 멀티태스킹 성능이 좋습니다.",
      threads: "스레드 수. 코어당 처리할 수 있는 동시 작업 수입니다.",
      tdp: "열 설계 전력 (Watts). 칩셋이 소비하는 최대 전력량입니다.",
      transistorCount: "트랜지스터 수 (십억 단위). 칩의 복잡성과 성능을 나타냅니다.",
      manufacturingProcess: "제조 공정 (나노미터). 작을수록 더 효율적입니다.",
      memoryBandwidth: "메모리 대역폭 (GB/s). 메모리 접근 속도를 나타냅니다.",
      cacheSize: "캐시 메모리 크기 (MB). 클수록 데이터 접근 속도가 빠릅니다.",
      instructionSet: "지원하는 명령어 집합. 프로세서가 실행할 수 있는 명령어 유형입니다.",
      architecture: "프로세서 아키텍처. 칩셋의 기본 설계 구조입니다.",

      // 성능 관련
      performanceScore: "종합 성능 점수 (100점 만점). 높을수록 더 좋은 성능입니다.",
      energyEfficiency: "에너지 효율성 점수 (100점 만점). 높을수록 더 효율적입니다.",
      thermalDesign: "열 설계 유형. 칩셋의 냉각 요구사항을 나타냅니다.",
      releaseYear: "출시 연도. 칩셋이 시장에 출시된 연도입니다.",

      // GPU 관련
      gpuCores: "GPU 코어 수. 그래픽 처리 능력을 나타냅니다.",
      gpuClockSpeed: "GPU 클럭 속도 (MHz). 그래픽 처리 속도를 나타냅니다.",
      rayTracingCores: "레이 트레이싱 코어 수. 실시간 광선 추적 기능을 위한 전용 코어입니다.",
      tensorCores: "텐서 코어 수. AI 및 머신러닝 연산을 가속화하는 전용 코어입니다.",

      // NPU 관련
      neuralEnginePerformance: "신경망 엔진 성능 (TOPS). AI 처리 능력을 나타냅니다.",
      aiAcceleration: "AI 가속 기능. 인공지능 작업 처리 속도를 향상시키는 기능입니다.",

      // 모뎀 관련
      modemGeneration: "모뎀 세대. 지원하는 이동통신 세대를 나타냅니다.",
      maxDownloadSpeed: "최대 다운로드 속도 (Mbps). 데이터 수신 속도를 나타냅니다.",
      maxUploadSpeed: "최대 업로드 속도 (Mbps). 데이터 송신 속도를 나타냅니다.",

      // 메모리 관련
      memoryType: "메모리 유형. 지원하는 메모리 기술을 나타냅니다.",
      maxMemory: "최대 지원 메모리 (GB). 칩셋이 지원하는 최대 메모리 용량입니다.",
      memoryChannels: "메모리 채널 수. 동시에 접근 가능한 메모리 경로 수입니다.",

      // 기타
      connectivity: "연결성. 지원하는 무선 및 유선 연결 기술입니다.",
      securityFeatures: "보안 기능. 내장된 하드웨어 보안 기능입니다.",
      displaySupport: "디스플레이 지원. 지원하는 최대 해상도 및 디스플레이 기술입니다.",

      // 한글 키에 대한 설명도 추가
      "제조 공정": "칩셋 제조에 사용된 공정 기술 (나노미터). 작을수록 더 효율적입니다.",
      "코어 수": "프로세서 코어 수. 많을수록 멀티태스킹 성능이 좋습니다.",
      "클럭 속도": "최대 클럭 주파수 (GHz). 높을수록 연산 속도가 빠릅니다.",
      "성능 점수": "종합 성능 점수 (100점 만점). 높을수록 더 좋은 성능입니다.",
      "에너지 효율": "에너지 효율성 점수 (100점 만점). 높을수록 더 효율적입니다.",
      출시년도: "칩셋이 시장에 출시된 연도입니다.",
      메모리: "지원하는 메모리 유형 및 용량에 관한 정보입니다.",
      그래픽: "내장된 그래픽 프로세서에 관한 정보입니다.",
    }

    return tooltips[key] || null
  }

  return (
    <TooltipProvider>
      <div className="space-y-8">
        <div className="bg-muted/50 p-4 rounded-md text-sm">
          <p className="font-medium mb-1">비교 가이드:</p>
          <ul className="list-disc pl-5 space-y-1">
            <li>각 컴포넌트(CPU, GPU 등)는 별도의 테이블로 표시됩니다.</li>
            <li>일부 칩셋에는 특정 컴포넌트나 사양이 없을 수 있으며, 이 경우 "—" 기호로 표시됩니다.</li>
            <li>
              사양 이름 옆의 <HelpCircle className="inline h-3 w-3" /> 아이콘에 마우스를 올리면 해당 사양에 대한 설명을
              볼 수 있습니다.
            </li>
            <li>서로 다른 제조사의 칩셋도 동일한 사양을 기준으로 비교됩니다.</li>
          </ul>
        </div>

        {Array.from(allComponentKeys).map((componentKey) => (
          <div key={componentKey} className="rounded-md border">
            <h3 className="px-4 py-2 font-semibold text-lg bg-muted capitalize">{componentKey} Comparison</h3>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[200px]">Specification</TableHead>
                  {chipsets.map((chipset) => (
                    <TableHead key={chipset.id}>{chipset.name}</TableHead>
                  ))}
                </TableRow>
              </TableHeader>
              <TableBody>
                {chipsets.some((chipset) => chipset.info[componentKey as keyof typeof chipset.info]) ? (
                  (() => {
                    // Get all unique spec keys for this component
                    const allSpecKeys = new Set<string>()
                    chipsets.forEach((chipset) => {
                      const componentInfo = chipset.info[componentKey as keyof typeof chipset.info]
                      if (componentInfo) {
                        Object.keys(componentInfo).forEach((key) => allSpecKeys.add(key))
                      }
                    })

                    return Array.from(allSpecKeys)
                      .sort()
                      .map((specKey) => (
                        <TableRow key={specKey}>
                          <TableCell className="font-medium flex items-center gap-1">
                            {formatKey(specKey)}
                            {getTooltipForKey(specKey) && (
                              <Tooltip>
                                <TooltipTrigger>
                                  <HelpCircle className="h-4 w-4 text-muted-foreground" />
                                </TooltipTrigger>
                                <TooltipContent>
                                  <p>{getTooltipForKey(specKey)}</p>
                                </TooltipContent>
                              </Tooltip>
                            )}
                          </TableCell>
                          {chipsets.map((chipset) => {
                            const componentInfo = chipset.info[componentKey as keyof typeof chipset.info]
                            return (
                              <TableCell key={chipset.id}>
                                {componentInfo
                                  ? formatValue(specKey, componentInfo[specKey as keyof typeof componentInfo])
                                  : "—"}
                              </TableCell>
                            )
                          })}
                        </TableRow>
                      ))
                  })()
                ) : (
                  <TableRow>
                    <TableCell colSpan={chipsets.length + 1} className="text-center py-4">
                      No {componentKey} data available for comparison
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        ))}
      </div>
    </TooltipProvider>
  )
}
