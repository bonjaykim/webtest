"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import type { Chipset } from "@/lib/sample-data"
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts"
import { ChartContainer, ChartTooltipContent } from "@/components/ui/chart"

interface ChipsetPerformanceChartProps {
  chipset: Chipset
}

export function ChipsetPerformanceChart({ chipset }: ChipsetPerformanceChartProps) {
  // Extract performance metrics
  const performanceMetrics = [
    { name: "Performance", value: chipset.info.performanceScore || 0 },
    { name: "Energy Efficiency", value: chipset.info.energyEfficiency || 0 },
  ]

  // Create data for radar chart based on chipset type
  const getSpecificMetrics = () => {
    const metrics = []

    if (chipset.kind === "CPU" || chipset.kind === "SoC") {
      if (chipset.info.clockSpeed) {
        metrics.push({
          name: "Clock Speed",
          value: chipset.info.clockSpeed * 20, // Scale for visualization
        })
      }
      if (chipset.info.cores) {
        metrics.push({
          name: "Cores",
          value: Math.min(chipset.info.cores, 100), // Cap at 100 for visualization
        })
      }
      if (chipset.info.cacheSize) {
        metrics.push({
          name: "Cache Size",
          value: Math.min(chipset.info.cacheSize / 3, 100), // Scale for visualization
        })
      }
    }

    if (chipset.kind === "GPU") {
      if (chipset.info.memoryBandwidth) {
        metrics.push({
          name: "Memory Bandwidth",
          value: Math.min(chipset.info.memoryBandwidth / 10, 100), // Scale for visualization
        })
      }
      if (chipset.info.tensorCores) {
        metrics.push({
          name: "Tensor Cores",
          value: Math.min(chipset.info.tensorCores / 5, 100), // Scale for visualization
        })
      }
      if (chipset.info.rayTracingCores) {
        metrics.push({
          name: "RT Cores",
          value: Math.min(chipset.info.rayTracingCores / 1.3, 100), // Scale for visualization
        })
      }
    }

    if (chipset.kind === "NPU" || chipset.kind === "DSP") {
      if (chipset.info.neuralEnginePerformance) {
        metrics.push({
          name: "Neural Performance",
          value: Math.min(chipset.info.neuralEnginePerformance * 5, 100), // Scale for visualization
        })
      }
    }

    if (chipset.info.tdp) {
      metrics.push({
        name: "Power Efficiency",
        value: Math.max(0, 100 - chipset.info.tdp / 3), // Invert TDP for efficiency
      })
    }

    if (chipset.info.manufacturingProcess) {
      metrics.push({
        name: "Process Node",
        value: Math.max(0, 100 - chipset.info.manufacturingProcess * 20), // Smaller is better
      })
    }

    return metrics
  }

  const specificMetrics = getSpecificMetrics()

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Core Performance Metrics</CardTitle>
          <CardDescription>Key performance indicators for {chipset.name}</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-80">
            <ChartContainer
              config={{
                performance: {
                  label: "Performance Score",
                  color: "hsl(var(--chart-1))",
                },
              }}
            >
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={performanceMetrics}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} />
                  <XAxis dataKey="name" />
                  <YAxis domain={[0, 100]} />
                  <Tooltip content={<ChartTooltipContent />} />
                  <Bar dataKey="value" fill="var(--color-performance)" name="Score" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </ChartContainer>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Detailed Performance Analysis</CardTitle>
          <CardDescription>Specific metrics for {chipset.kind} type chipsets</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-80">
            <ChartContainer
              config={{
                metrics: {
                  label: "Score",
                  color: "hsl(var(--chart-2))",
                },
              }}
            >
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={specificMetrics}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} />
                  <XAxis dataKey="name" />
                  <YAxis domain={[0, 100]} />
                  <Tooltip content={<ChartTooltipContent />} />
                  <Bar dataKey="value" fill="var(--color-metrics)" name="Score" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </ChartContainer>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
