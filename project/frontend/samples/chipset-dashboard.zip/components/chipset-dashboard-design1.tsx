"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import { Cpu, Smartphone, Layers, Zap, Radio, X } from "lucide-react"
import { type ChipsetKind, type Chipset, getChipsetKinds, getChipsetsByKind, getChipsetCount } from "@/lib/sample-data"
import { ChipsetComparisonTable } from "@/components/chipset-comparison-table"

export function ChipsetDashboardDesign1() {
  const [selectedKind, setSelectedKind] = useState<ChipsetKind | null>(null)
  const [selectedChipsets, setSelectedChipsets] = useState<Chipset[]>([])
  const chipsetKinds = getChipsetKinds()

  const handleKindSelect = (kind: ChipsetKind) => {
    setSelectedKind(kind)
  }

  const handleCompareToggle = (chipset: Chipset) => {
    if (selectedChipsets.some((c) => c.id === chipset.id)) {
      setSelectedChipsets(selectedChipsets.filter((c) => c.id !== chipset.id))
    } else {
      if (selectedChipsets.length < 3) {
        setSelectedChipsets([...selectedChipsets, chipset])
        // Scroll to comparison section when a chipset is added
        setTimeout(() => {
          document.getElementById("comparison-section")?.scrollIntoView({ behavior: "smooth" })
        }, 100)
      } else {
        // Show a toast or alert that max 3 chipsets can be compared
        alert("최대 3개의 칩셋만 비교할 수 있습니다.")
      }
    }
  }

  const removeFromComparison = (chipset: Chipset) => {
    setSelectedChipsets(selectedChipsets.filter((c) => c.id !== chipset.id))
  }

  const getIconForKind = (kind: ChipsetKind) => {
    switch (kind) {
      case "qualcomm":
        return <Smartphone className="h-8 w-8 text-red-500" />
      case "exynos":
        return <Cpu className="h-8 w-8 text-blue-500" />
      case "mediatek":
        return <Layers className="h-8 w-8 text-green-500" />
      case "apple":
        return <Zap className="h-8 w-8 text-purple-500" />
      case "intel":
        return <Radio className="h-8 w-8 text-sky-500" />
    }
  }

  const getColorForKind = (kind: ChipsetKind) => {
    switch (kind) {
      case "qualcomm":
        return "bg-red-500/10 hover:bg-red-500/20"
      case "exynos":
        return "bg-blue-500/10 hover:bg-blue-500/20"
      case "mediatek":
        return "bg-green-500/10 hover:bg-green-500/20"
      case "apple":
        return "bg-purple-500/10 hover:bg-purple-500/20"
      case "intel":
        return "bg-sky-500/10 hover:bg-sky-500/20"
    }
  }

  const getKindDisplayName = (kind: ChipsetKind) => {
    switch (kind) {
      case "qualcomm":
        return "Qualcomm"
      case "exynos":
        return "Samsung Exynos"
      case "mediatek":
        return "MediaTek"
      case "apple":
        return "Apple"
      case "intel":
        return "Intel"
    }
  }

  // Add this function to handle adding chipsets from different manufacturers
  const handleAddFromDifferentManufacturer = () => {
    // If no kind is selected yet, select the first one
    if (!selectedKind) {
      setSelectedKind(chipsetKinds[0])
      return
    }

    // Find the next kind in the list
    const currentIndex = chipsetKinds.indexOf(selectedKind)
    const nextIndex = (currentIndex + 1) % chipsetKinds.length
    setSelectedKind(chipsetKinds[nextIndex])
  }

  // 차트 색상 테마를 위한 함수 추가
  const getChartColorForKind = (kind: ChipsetKind) => {
    switch (kind) {
      case "qualcomm":
        return "var(--chart-1)" // 빨간색 계열
      case "exynos":
        return "var(--chart-2)" // 파란색 계열
      case "mediatek":
        return "var(--chart-3)" // 녹색 계열
      case "apple":
        return "var(--chart-4)" // 보라색 계열
      case "intel":
        return "var(--chart-5)" // 하늘색 계열
    }
  }

  // 카드 클릭 시 차트 색상 테마 적용을 위한 스타일 추가
  const getCardStyle = (kind: ChipsetKind | null) => {
    if (!kind) return {}

    const chartColor = getChartColorForKind(kind)
    return {
      "--selected-chart-color": chartColor,
    } as React.CSSProperties
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center mb-2">
        <h2 className="text-xl font-semibold">Chipset 제조사</h2>
        {selectedChipsets.length > 0 && (
          <Button
            variant="outline"
            onClick={() => document.getElementById("comparison-section")?.scrollIntoView({ behavior: "smooth" })}
          >
            선택한 칩셋 비교하기 ({selectedChipsets.length})
          </Button>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
        {chipsetKinds.map((kind) => (
          <Card
            key={kind}
            className={`cursor-pointer transition-colors ${selectedKind === kind ? getColorForKind(kind) : "hover:bg-muted/50"}`}
            onClick={() => handleKindSelect(kind)}
            style={selectedKind === kind ? getCardStyle(kind) : {}}
          >
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-xl font-medium">{getKindDisplayName(kind)}</CardTitle>
              {getIconForKind(kind)}
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{getChipsetCount(kind)}</div>
              <p className="text-xs text-muted-foreground">
                {getChipsetCount(kind) === 1 ? "Chipset" : "Chipsets"} available
              </p>
            </CardContent>
          </Card>
        ))}
      </div>

      {selectedKind && (
        <Card className="mt-6">
          <CardHeader>
            <CardTitle className="flex items-center">
              {getIconForKind(selectedKind)}
              <span className="ml-2">{getKindDisplayName(selectedKind)} Chipsets</span>
            </CardTitle>
            <CardDescription>Select chipsets to view details or compare specifications</CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue={getChipsetsByKind(selectedKind)[0]?.id}>
              <TabsList className="mb-2 flex flex-wrap h-auto">
                {getChipsetsByKind(selectedKind).map((chipset) => (
                  <TabsTrigger key={chipset.id} value={chipset.id} className="flex items-center gap-2 my-1">
                    {chipset.name}
                    <Checkbox
                      checked={selectedChipsets.some((c) => c.id === chipset.id)}
                      onCheckedChange={() => handleCompareToggle(chipset)}
                      onClick={(e) => e.stopPropagation()}
                      aria-label={`Compare ${chipset.name}`}
                    />
                  </TabsTrigger>
                ))}
              </TabsList>
              <p className="text-sm text-muted-foreground mb-4">
                체크박스를 클릭하여 비교할 칩셋을 선택하세요. 서로 다른 제조사의 칩셋도 비교할 수 있습니다.
              </p>

              {/* Add this button to switch between manufacturers */}
              {selectedChipsets.length > 0 && selectedChipsets.length < 3 && (
                <div className="mb-4 p-3 border rounded-md bg-muted/30">
                  <p className="text-sm mb-2">다른 제조사의 칩셋과 비교하려면:</p>
                  <Button variant="outline" onClick={handleAddFromDifferentManufacturer} className="text-sm">
                    다른 제조사 칩셋 선택하기
                  </Button>
                </div>
              )}

              {getChipsetsByKind(selectedKind).map((chipset) => (
                <TabsContent key={chipset.id} value={chipset.id}>
                  <Card>
                    <CardHeader>
                      <CardTitle>{chipset.name}</CardTitle>
                      <CardDescription>
                        {getKindDisplayName(chipset.kind)} - ID: {chipset.id}
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-6">
                        {Object.entries(chipset.info).map(([componentKey, componentInfo]) => (
                          <div key={componentKey}>
                            <h3 className="text-lg font-semibold mb-3 capitalize">{componentKey}</h3>
                            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                              {Object.entries(componentInfo).map(([key, value]) => (
                                <div key={key} className="flex flex-col space-y-1">
                                  <span className="text-sm font-medium text-muted-foreground capitalize">
                                    {key.replace(/([A-Z])/g, " $1").trim()}
                                  </span>
                                  <span className="font-medium">
                                    {Array.isArray(value)
                                      ? value.join(", ")
                                      : typeof value === "number"
                                        ? key.includes("Year")
                                          ? value
                                          : value.toLocaleString()
                                        : value}
                                  </span>
                                </div>
                              ))}
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
              ))}
            </Tabs>
          </CardContent>
        </Card>
      )}

      {selectedChipsets.length > 0 && (
        <Card className="mt-6" id="comparison-section">
          <CardHeader>
            <CardTitle>Chipset Comparison</CardTitle>
            <CardDescription>
              Comparing {selectedChipsets.length} chipset{selectedChipsets.length > 1 ? "s" : ""}
            </CardDescription>
            <div className="flex flex-wrap gap-2 mt-2">
              {selectedChipsets.map((chipset) => (
                <Badge key={chipset.id} variant="secondary" className="flex items-center gap-1">
                  {chipset.name}
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-4 w-4 ml-1 p-0"
                    onClick={() => removeFromComparison(chipset)}
                  >
                    <X className="h-3 w-3" />
                    <span className="sr-only">Remove {chipset.name} from comparison</span>
                  </Button>
                </Badge>
              ))}
            </div>
          </CardHeader>
          <CardContent>
            <ChipsetComparisonTable chipsets={selectedChipsets} />
          </CardContent>
        </Card>
      )}
    </div>
  )
}
