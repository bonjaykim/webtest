"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { BarChart3, PinIcon as Chip, Cpu, Layers, MicroscopeIcon as Microchip, Radio, X } from "lucide-react"
import { type ChipsetKind, type Chipset, getChipsetKinds, getChipsetsByKind, getChipsetCount } from "@/lib/sample-data"
import { ChipsetComparisonTable } from "@/components/chipset-comparison-table"
import { ChipsetDetailView } from "@/components/chipset-detail-view"
import { ChipsetPerformanceChart } from "@/components/chipset-performance-chart"

export function ChipsetDashboardDesign2() {
  const [selectedKind, setSelectedKind] = useState<ChipsetKind>(getChipsetKinds()[0])
  const [selectedChipset, setSelectedChipset] = useState<Chipset | null>(
    getChipsetsByKind(getChipsetKinds()[0])[0] || null,
  )
  const [selectedChipsets, setSelectedChipsets] = useState<Chipset[]>([])
  const [activeView, setActiveView] = useState<"details" | "performance" | "comparison">("details")

  const chipsetKinds = getChipsetKinds()
  const chipsetsForKind = getChipsetsByKind(selectedKind)

  const handleKindSelect = (kind: ChipsetKind) => {
    setSelectedKind(kind)
    const firstChipset = getChipsetsByKind(kind)[0]
    setSelectedChipset(firstChipset || null)
  }

  const handleChipsetSelect = (chipset: Chipset) => {
    setSelectedChipset(chipset)
  }

  const toggleCompare = (chipset: Chipset) => {
    if (selectedChipsets.some((c) => c.id === chipset.id)) {
      setSelectedChipsets(selectedChipsets.filter((c) => c.id !== chipset.id))
    } else {
      if (selectedChipsets.length < 3) {
        setSelectedChipsets([...selectedChipsets, chipset])
        setActiveView("comparison")
      }
    }
  }

  const removeFromComparison = (chipset: Chipset) => {
    setSelectedChipsets(selectedChipsets.filter((c) => c.id !== chipset.id))
  }

  const getIconForKind = (kind: ChipsetKind) => {
    switch (kind) {
      case "CPU":
        return <Cpu className="h-5 w-5" />
      case "GPU":
        return <Chip className="h-5 w-5" />
      case "NPU":
        return <Microchip className="h-5 w-5" />
      case "SoC":
        return <Layers className="h-5 w-5" />
      case "DSP":
        return <Radio className="h-5 w-5" />
    }
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-[280px_1fr] gap-6">
      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle>Chipset Types</CardTitle>
            <CardDescription>Select a chipset type to view</CardDescription>
          </CardHeader>
          <CardContent className="p-0">
            <div className="space-y-1 p-2">
              {chipsetKinds.map((kind) => (
                <Button
                  key={kind}
                  variant={selectedKind === kind ? "default" : "ghost"}
                  className="w-full justify-start"
                  onClick={() => handleKindSelect(kind)}
                >
                  <div className="flex items-center">
                    {getIconForKind(kind)}
                    <span className="ml-2">{kind}</span>
                    <Badge variant="secondary" className="ml-auto">
                      {getChipsetCount(kind)}
                    </Badge>
                  </div>
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>{selectedKind} Chipsets</CardTitle>
            <CardDescription>Select a chipset to view details</CardDescription>
          </CardHeader>
          <CardContent className="p-0">
            <div className="space-y-1 p-2">
              {chipsetsForKind.map((chipset) => (
                <div key={chipset.id} className="flex items-center">
                  <Button
                    variant={selectedChipset?.id === chipset.id ? "default" : "ghost"}
                    className="w-full justify-start"
                    onClick={() => handleChipsetSelect(chipset)}
                  >
                    {chipset.name}
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    className={
                      selectedChipsets.some((c) => c.id === chipset.id) ? "bg-primary/20 hover:bg-primary/30" : ""
                    }
                    onClick={() => toggleCompare(chipset)}
                  >
                    {selectedChipsets.some((c) => c.id === chipset.id) ? "Remove" : "Compare"}
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="space-y-6">
        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-2xl">{selectedChipset?.name || "Select a chipset"}</CardTitle>
              <Tabs value={activeView} onValueChange={(v) => setActiveView(v as any)}>
                <TabsList>
                  <TabsTrigger value="details">Details</TabsTrigger>
                  <TabsTrigger value="performance">Performance</TabsTrigger>
                  <TabsTrigger value="comparison">Comparison</TabsTrigger>
                </TabsList>
              </Tabs>
            </div>
            {selectedChipsets.length > 0 && (
              <div className="flex flex-wrap gap-2 mt-4">
                <span className="text-sm font-medium text-muted-foreground">Comparing:</span>
                {selectedChipsets.map((chipset) => (
                  <Badge key={chipset.id} variant="secondary" className="flex items-center gap-1">
                    {chipset.name}
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-4 w-4 ml-1 p-0"
                      onClick={() => removeFromComparison(chipset)}
                    >
                      <X className="h-3 w-3" />
                      <span className="sr-only">Remove {chipset.name} from comparison</span>
                    </Button>
                  </Badge>
                ))}
              </div>
            )}
          </CardHeader>
          <CardContent>
            {activeView === "details" && selectedChipset && <ChipsetDetailView chipset={selectedChipset} />}

            {activeView === "performance" && selectedChipset && <ChipsetPerformanceChart chipset={selectedChipset} />}

            {activeView === "comparison" &&
              (selectedChipsets.length > 0 ? (
                <ChipsetComparisonTable chipsets={selectedChipsets} />
              ) : (
                <div className="flex flex-col items-center justify-center py-12 text-center">
                  <BarChart3 className="h-12 w-12 text-muted-foreground mb-4" />
                  <h3 className="text-lg font-medium">No chipsets selected for comparison</h3>
                  <p className="text-muted-foreground mt-2">
                    Select chipsets using the "Compare" button to see a comparison
                  </p>
                </div>
              ))}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
