export type ChipsetKind = "qualcomm" | "exynos" | "mediatek" | "apple" | "intel"

// 더 유연한 타입 정의
export type ChipsetComponentInfo = Record<string, any>
export type ChipsetInfo = Record<string, ChipsetComponentInfo>

export interface Chipset {
  id: string
  kind: ChipsetKind
  name: string
  info: ChipsetInfo
}

// 샘플 데이터에 한글 키와 다양한 형태의 값을 가진 항목 추가
export const sampleChipsets: Chipset[] = [
  // Qualcomm Chipsets
  {
    id: "q-1",
    kind: "qualcomm",
    name: "Snapdragon 8 Gen 2",
    info: {
      cpu: {
        clockSpeed: 3.2,
        cores: 8,
        tdp: 5,
        transistorCount: 8.9,
        manufacturingProcess: 4,
        architecture: "ARMv9",
        performanceScore: 90,
        energyEfficiency: 93,
        thermalDesign: "Mobile",
        releaseYear: 2022,
      },
      gpu: {
        architecture: "Adreno 740",
        performanceScore: 88,
        energyEfficiency: 85,
        clockSpeed: 0.9,
      },
      npu: {
        neuralEnginePerformance: 4.8,
        performanceScore: 92,
        energyEfficiency: 90,
      },
      dsp: {
        architecture: "Hexagon",
        performanceScore: 85,
      },
      modem: {
        architecture: "X70",
        performanceScore: 95,
      },
      // 한글 키와 다양한 값 형태 추가
      "제조 공정": {
        "공정 기술": "TSMC N4",
        "트랜지스터 수": "80억 개 이상",
        "다이 크기": "125mm²",
      },
      "게임 성능": {
        프레임레이트: "매우 높음",
        "그래픽 품질": 9.2,
        "지원 기술": ["Vulkan 1.3", "OpenGL ES 3.2", "HDR 게이밍"],
      },
    },
  },
  {
    id: "q-2",
    kind: "qualcomm",
    name: "Snapdragon 888",
    info: {
      cpu: {
        clockSpeed: 2.84,
        cores: 8,
        tdp: 5.5,
        transistorCount: 5.3,
        manufacturingProcess: 5,
        architecture: "ARMv8.2-A",
        performanceScore: 82,
        energyEfficiency: 80,
        thermalDesign: "Mobile",
        releaseYear: 2020,
      },
      gpu: {
        architecture: "Adreno 660",
        performanceScore: 80,
        energyEfficiency: 78,
        clockSpeed: 0.84,
      },
      npu: {
        neuralEnginePerformance: 3.2,
        performanceScore: 85,
        energyEfficiency: 82,
      },
      dsp: {
        architecture: "Hexagon 780",
        performanceScore: 80,
      },
      modem: {
        architecture: "X60",
        performanceScore: 88,
      },
      // 한글 키 추가
      "제조 공정": {
        "공정 기술": "Samsung 5nm",
        "트랜지스터 수": "53억 개",
        "다이 크기": "120mm²",
      },
    },
  },

  // Exynos Chipsets
  {
    id: "e-1",
    kind: "exynos",
    name: "Exynos 2200",
    info: {
      cpu: {
        clockSpeed: 2.8,
        cores: 8,
        tdp: 5.2,
        transistorCount: 7.8,
        manufacturingProcess: 4,
        architecture: "ARMv9",
        performanceScore: 85,
        energyEfficiency: 82,
        thermalDesign: "Mobile",
        releaseYear: 2022,
      },
      gpu: {
        architecture: "Xclipse 920",
        performanceScore: 83,
        energyEfficiency: 80,
        rayTracingCores: 4,
      },
      npu: {
        neuralEnginePerformance: 4.2,
        performanceScore: 88,
        energyEfficiency: 85,
      },
      isp: {
        performanceScore: 90,
      },
      modem: {
        architecture: "5G",
        performanceScore: 90,
      },
    },
  },
  {
    id: "e-2",
    kind: "exynos",
    name: "Exynos 2100",
    info: {
      cpu: {
        clockSpeed: 2.9,
        cores: 8,
        tdp: 5.7,
        transistorCount: 5.6,
        manufacturingProcess: 5,
        architecture: "ARMv8.2-A",
        performanceScore: 80,
        energyEfficiency: 78,
        thermalDesign: "Mobile",
        releaseYear: 2021,
      },
      gpu: {
        architecture: "Mali-G78",
        performanceScore: 75,
        energyEfficiency: 72,
      },
      npu: {
        neuralEnginePerformance: 3.0,
        performanceScore: 82,
        energyEfficiency: 80,
      },
      isp: {
        performanceScore: 85,
      },
      modem: {
        architecture: "5G",
        performanceScore: 85,
      },
    },
  },

  // MediaTek Chipsets
  {
    id: "m-1",
    kind: "mediatek",
    name: "Dimensity 9200",
    info: {
      cpu: {
        clockSpeed: 3.05,
        cores: 8,
        tdp: 5.0,
        transistorCount: 6.5,
        manufacturingProcess: 4,
        architecture: "ARMv9",
        performanceScore: 88,
        energyEfficiency: 90,
        thermalDesign: "Mobile",
        releaseYear: 2022,
      },
      gpu: {
        architecture: "Immortalis-G715",
        performanceScore: 85,
        energyEfficiency: 87,
        rayTracingCores: 2,
      },
      npu: {
        neuralEnginePerformance: 4.5,
        performanceScore: 90,
        energyEfficiency: 88,
      },
      modem: {
        architecture: "5G",
        performanceScore: 92,
      },
    },
  },
  {
    id: "m-2",
    kind: "mediatek",
    name: "Dimensity 8100",
    info: {
      cpu: {
        clockSpeed: 2.85,
        cores: 8,
        tdp: 4.8,
        transistorCount: 5.2,
        manufacturingProcess: 5,
        architecture: "ARMv8.2-A",
        performanceScore: 82,
        energyEfficiency: 85,
        thermalDesign: "Mobile",
        releaseYear: 2022,
      },
      gpu: {
        architecture: "Mali-G610",
        performanceScore: 78,
        energyEfficiency: 82,
      },
      npu: {
        neuralEnginePerformance: 3.8,
        performanceScore: 85,
        energyEfficiency: 84,
      },
      modem: {
        architecture: "5G",
        performanceScore: 88,
      },
    },
  },

  // Apple Chipsets
  {
    id: "a-1",
    kind: "apple",
    name: "A16 Bionic",
    info: {
      cpu: {
        clockSpeed: 3.46,
        cores: 6,
        tdp: 4.5,
        transistorCount: 16,
        manufacturingProcess: 4,
        architecture: "ARMv8.6-A",
        performanceScore: 95,
        energyEfficiency: 96,
        thermalDesign: "Mobile Premium",
        releaseYear: 2022,
      },
      gpu: {
        architecture: "Apple Custom GPU",
        performanceScore: 92,
        energyEfficiency: 94,
        cores: 5,
      },
      npu: {
        neuralEnginePerformance: 17.0,
        performanceScore: 98,
        energyEfficiency: 95,
      },
      isp: {
        performanceScore: 96,
      },
      // 한글 키와 다양한 값 형태 추가
      "성능 지표": {
        "Geekbench 단일 코어": 2505,
        "Geekbench 멀티 코어": 6375,
        AnTuTu: 1250000,
        "AI 벤치마크": "업계 최고",
      },
      메모리: {
        타입: "LPDDR5",
        대역폭: "50GB/s",
        용량: "6GB",
      },
    },
  },
  {
    id: "a-2",
    kind: "apple",
    name: "A15 Bionic",
    info: {
      cpu: {
        clockSpeed: 3.22,
        cores: 6,
        tdp: 4.8,
        transistorCount: 15,
        manufacturingProcess: 5,
        architecture: "ARMv8.5-A",
        performanceScore: 90,
        energyEfficiency: 92,
        thermalDesign: "Mobile Premium",
        releaseYear: 2021,
      },
      gpu: {
        architecture: "Apple Custom GPU",
        performanceScore: 88,
        energyEfficiency: 90,
        cores: 5,
      },
      npu: {
        neuralEnginePerformance: 15.8,
        performanceScore: 95,
        energyEfficiency: 92,
      },
      isp: {
        performanceScore: 92,
      },
    },
  },

  // Intel Chipsets
  {
    id: "i-1",
    kind: "intel",
    name: "Core i9-12900K",
    info: {
      cpu: {
        clockSpeed: 5.2,
        cores: 16,
        tdp: 125,
        transistorCount: 21.7,
        manufacturingProcess: 10,
        cacheSize: 44,
        instructionSet: ["x86-64", "AVX-512", "SSE4.2"],
        architecture: "Alder Lake",
        performanceScore: 97,
        energyEfficiency: 78,
        thermalDesign: "High-end",
        releaseYear: 2021,
      },
      gpu: {
        architecture: "Intel UHD Graphics 770",
        performanceScore: 65,
        energyEfficiency: 70,
      },
    },
  },
  {
    id: "i-2",
    kind: "intel",
    name: "Core i7-1260P",
    info: {
      cpu: {
        clockSpeed: 4.7,
        cores: 12,
        tdp: 28,
        transistorCount: 15.3,
        manufacturingProcess: 10,
        cacheSize: 24,
        instructionSet: ["x86-64", "AVX2", "SSE4.2"],
        architecture: "Alder Lake",
        performanceScore: 85,
        energyEfficiency: 82,
        thermalDesign: "Mobile",
        releaseYear: 2022,
      },
      gpu: {
        architecture: "Intel Iris Xe",
        performanceScore: 70,
        energyEfficiency: 75,
      },
    },
  },
]

export const getChipsetsByKind = (kind: ChipsetKind): Chipset[] => {
  return sampleChipsets.filter((chipset) => chipset.kind === kind)
}

export const getChipsetKinds = (): ChipsetKind[] => {
  return Array.from(new Set(sampleChipsets.map((chipset) => chipset.kind)))
}

export const getChipsetById = (id: string): Chipset | undefined => {
  return sampleChipsets.find((chipset) => chipset.id === id)
}

export const getChipsetCount = (kind: ChipsetKind): number => {
  return sampleChipsets.filter((chipset) => chipset.kind === kind).length
}
