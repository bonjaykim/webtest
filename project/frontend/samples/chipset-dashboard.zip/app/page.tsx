import { ChipsetDashboardDesign1 } from "@/components/chipset-dashboard-design1"

export default function Home() {
  return (
    <div className="container mx-auto py-6">
      <h1 className="text-3xl font-bold mb-6">Chipset KPI Dashboard</h1>
      <ChipsetDashboardDesign1 />
    </div>
  )
}
