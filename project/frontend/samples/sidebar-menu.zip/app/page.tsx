"use client"

import { ImprovedSidebar } from "@/components/improved-sidebar"

export default function Home() {
  return (
    <div className="min-h-screen">
      <ImprovedSidebar />
    </div>
  )
}
