"use client"

import * as React from "react"
import {
  Home,
  ChevronLeft,
  ChevronRight,
  Settings,
  Users,
  FileText,
  HelpCircle,
  Menu,
  X,
  Briefcase,
  ImageIcon,
  LayoutDashboard,
} from "lucide-react"

import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarMenuSub,
  SidebarMenuSubButton,
  SidebarMenuSubItem,
  SidebarRail,
  SidebarProvider,
  SidebarInset,
  SidebarFooter,
} from "@/components/ui/sidebar"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

export function SidebarVariation2() {
  const [collapsed, setCollapsed] = React.useState(false)
  const [iconOnly, setIconOnly] = React.useState(false)

  const menuGroups = [
    {
      label: "메인",
      items: [
        {
          title: "대시보드",
          icon: <LayoutDashboard className="size-4" />,
          url: "#",
          items: [
            { title: "개요", url: "#" },
            { title: "통계", url: "#" },
          ],
        },
        {
          title: "프로젝트",
          icon: <Briefcase className="size-4" />,
          url: "#",
          items: [
            { title: "모든 프로젝트", url: "#" },
            { title: "최근 프로젝트", url: "#" },
          ],
        },
      ],
    },
    {
      label: "콘텐츠",
      items: [
        {
          title: "문서",
          icon: <FileText className="size-4" />,
          url: "#",
          items: [
            { title: "모든 문서", url: "#" },
            { title: "공유 문서", url: "#" },
          ],
        },
        {
          title: "미디어",
          icon: <ImageIcon className="size-4" />,
          url: "#",
          items: [
            { title: "이미지", url: "#" },
            { title: "비디오", url: "#" },
          ],
        },
      ],
    },
    {
      label: "관리",
      items: [
        {
          title: "사용자",
          icon: <Users className="size-4" />,
          url: "#",
          items: [
            { title: "팀원", url: "#" },
            { title: "권한", url: "#" },
          ],
        },
        {
          title: "설정",
          icon: <Settings className="size-4" />,
          url: "#",
          items: [
            { title: "일반", url: "#" },
            { title: "보안", url: "#" },
          ],
        },
      ],
    },
  ]

  return (
    <SidebarProvider>
      <Sidebar
        className={cn(
          "transition-all duration-300 bg-zinc-50 dark:bg-zinc-950",
          collapsed ? "w-0" : iconOnly ? "w-16" : "w-64",
        )}
      >
        <SidebarHeader className="flex justify-between items-center">
          <SidebarMenu>
            <SidebarMenuItem>
              <SidebarMenuButton size="lg" asChild>
                <a href="#" className="flex items-center">
                  <div className="flex aspect-square size-8 items-center justify-center rounded-lg bg-teal-600 text-white">
                    <Home className="size-4" />
                  </div>
                  {!iconOnly && <span className="ml-2 font-semibold">홈</span>}
                </a>
              </SidebarMenuButton>
            </SidebarMenuItem>
          </SidebarMenu>
          {!collapsed && (
            <Button variant="ghost" size="icon" onClick={() => setIconOnly(!iconOnly)} className="mr-2">
              {iconOnly ? <ChevronRight className="size-4" /> : <ChevronLeft className="size-4" />}
            </Button>
          )}
        </SidebarHeader>
        <SidebarContent>
          {menuGroups.map((group) => (
            <SidebarGroup key={group.label}>
              {!iconOnly && <SidebarGroupLabel>{group.label}</SidebarGroupLabel>}
              <SidebarGroupContent>
                <SidebarMenu>
                  {group.items.map((item) => (
                    <SidebarMenuItem key={item.title}>
                      <SidebarMenuButton asChild>
                        <a href={item.url} className="flex items-center">
                          {item.icon}
                          {!iconOnly && <span className="ml-2">{item.title}</span>}
                        </a>
                      </SidebarMenuButton>
                      {!iconOnly && item.items?.length > 0 && (
                        <SidebarMenuSub>
                          {item.items.map((subItem) => (
                            <SidebarMenuSubItem key={subItem.title}>
                              <SidebarMenuSubButton asChild>
                                <a href={subItem.url}>{subItem.title}</a>
                              </SidebarMenuSubButton>
                            </SidebarMenuSubItem>
                          ))}
                        </SidebarMenuSub>
                      )}
                    </SidebarMenuItem>
                  ))}
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>
          ))}
        </SidebarContent>
        <SidebarFooter>
          {!iconOnly ? (
            <div className="p-4">
              <Button variant="outline" className="w-full">
                <HelpCircle className="mr-2 size-4" />
                도움말
              </Button>
            </div>
          ) : (
            <div className="p-2 flex justify-center">
              <Button variant="outline" size="icon">
                <HelpCircle className="size-4" />
              </Button>
            </div>
          )}
        </SidebarFooter>
        <SidebarRail />
      </Sidebar>
      <SidebarInset className="flex-1">
        <header className="flex h-16 shrink-0 items-center gap-2 border-b px-4">
          {collapsed ? (
            <Button variant="ghost" size="icon" onClick={() => setCollapsed(false)}>
              <Menu className="size-4" />
            </Button>
          ) : (
            <Button variant="ghost" size="icon" onClick={() => setCollapsed(true)}>
              <X className="size-4" />
            </Button>
          )}
          <h1 className="text-xl font-semibold">변형 2: 그룹 레이블이 있는 메뉴</h1>
        </header>
        <div className="p-4">
          <div className="rounded-lg border p-4">
            <h2 className="text-lg font-medium">콘텐츠 영역</h2>
            <p className="mt-2 text-muted-foreground">여기에 페이지 콘텐츠가 표시됩니다.</p>
          </div>
        </div>
      </SidebarInset>
    </SidebarProvider>
  )
}
