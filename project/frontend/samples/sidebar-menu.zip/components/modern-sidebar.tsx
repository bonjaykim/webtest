"use client"

import * as React from "react"
import {
  Home,
  ChevronDown,
  ChevronRight,
  Settings,
  Menu,
  X,
  LayoutDashboard,
  Briefcase,
  MessageSquare,
  Bell,
  Search,
  Bookmark,
  Calendar,
  BarChart3,
  Layers,
  Globe,
  LogOut,
} from "lucide-react"
import { motion } from "framer-motion"

import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"

// 모던 사이드바 1: 미니멀 디자인
export function ModernSidebar1() {
  const [collapsed, setCollapsed] = React.useState(false)
  const [iconOnly, setIconOnly] = React.useState(false)
  const [activeMenu, setActiveMenu] = React.useState("dashboard")
  const [openSubMenus, setOpenSubMenus] = React.useState<Record<string, boolean>>({
    dashboard: true,
  })

  const toggleSubMenu = (key: string) => {
    setOpenSubMenus((prev) => ({
      ...prev,
      [key]: !prev[key],
    }))
  }

  const menuItems = [
    {
      key: "dashboard",
      label: "대시보드",
      icon: <LayoutDashboard className="size-4" />,
      badge: "3",
      subItems: [
        { key: "analytics", label: "분석", isActive: true },
        { key: "overview", label: "개요" },
        { key: "reports", label: "보고서" },
      ],
    },
    {
      key: "projects",
      label: "프로젝트",
      icon: <Briefcase className="size-4" />,
      subItems: [
        { key: "active", label: "진행 중" },
        { key: "archived", label: "보관됨" },
      ],
    },
    {
      key: "messages",
      label: "메시지",
      icon: <MessageSquare className="size-4" />,
      badge: "5",
      subItems: [
        { key: "inbox", label: "받은 메시지" },
        { key: "sent", label: "보낸 메시지" },
        { key: "drafts", label: "임시 보관함" },
      ],
    },
    {
      key: "notifications",
      label: "알림",
      icon: <Bell className="size-4" />,
      subItems: [
        { key: "all", label: "모든 알림" },
        { key: "mentions", label: "멘션" },
      ],
    },
    {
      key: "settings",
      label: "설정",
      icon: <Settings className="size-4" />,
      subItems: [
        { key: "profile", label: "프로필" },
        { key: "security", label: "보안" },
        { key: "preferences", label: "환경설정" },
      ],
    },
  ]

  return (
    <div className="flex h-screen w-full bg-gray-50 dark:bg-gray-950">
      <div
        className={cn(
          "relative flex flex-col border-r bg-white transition-all duration-300 dark:bg-gray-900 dark:border-gray-800",
          collapsed ? "w-0" : iconOnly ? "w-16" : "w-64",
        )}
      >
        {/* 사이드바 헤더 */}
        <div className="flex h-16 items-center justify-between border-b px-4 dark:border-gray-800">
          {!iconOnly && !collapsed && (
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-violet-500 to-indigo-600">
                <Layers className="size-4 text-white" />
              </div>
              <span className="font-semibold text-gray-900 dark:text-white">워크스페이스</span>
            </div>
          )}
          {iconOnly && !collapsed && (
            <div className="mx-auto flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-violet-500 to-indigo-600">
              <Layers className="size-4 text-white" />
            </div>
          )}
          {!collapsed && (
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8 rounded-full text-gray-500 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white"
              onClick={() => setIconOnly(!iconOnly)}
            >
              {iconOnly ? <ChevronRight className="size-4" /> : <Menu className="size-4" />}
            </Button>
          )}
        </div>

        {/* 검색 */}
        {!collapsed && !iconOnly && (
          <div className="px-4 py-3">
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 size-4 text-gray-500 dark:text-gray-400" />
              <Input
                type="search"
                placeholder="검색..."
                className="w-full rounded-lg border border-gray-200 bg-gray-50 pl-9 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-300"
              />
            </div>
          </div>
        )}

        {/* 메뉴 아이템 */}
        <div className="flex-1 overflow-y-auto py-2">
          <nav className="px-2">
            {/* 홈 메뉴 */}
            <div className="mb-2">
              <button
                className={cn(
                  "flex w-full items-center rounded-lg px-3 py-2 text-sm font-medium transition-colors",
                  "text-gray-900 hover:bg-gray-100 dark:text-white dark:hover:bg-gray-800",
                  "bg-gray-100 dark:bg-gray-800",
                )}
              >
                <Home className="mr-3 size-4" />
                {!iconOnly && <span>홈</span>}
              </button>
            </div>

            {/* 메뉴 섹션 */}
            <div className="mb-2">
              {!iconOnly && (
                <h3 className="mb-1 px-3 text-xs font-semibold uppercase text-gray-500 dark:text-gray-400">메뉴</h3>
              )}
              <div className="space-y-1">
                {menuItems.map((item) => (
                  <div key={item.key}>
                    <button
                      className={cn(
                        "flex w-full items-center justify-between rounded-lg px-3 py-2 text-sm font-medium transition-colors",
                        "text-gray-900 hover:bg-gray-100 dark:text-white dark:hover:bg-gray-800",
                        activeMenu === item.key && "bg-gray-100 dark:bg-gray-800",
                      )}
                      onClick={() => {
                        setActiveMenu(item.key)
                        toggleSubMenu(item.key)
                      }}
                    >
                      <div className="flex items-center">
                        <span className="mr-3">{item.icon}</span>
                        {!iconOnly && <span>{item.label}</span>}
                      </div>
                      {!iconOnly && (
                        <div className="flex items-center">
                          {item.badge && (
                            <Badge
                              className="mr-1 bg-violet-100 text-violet-800 hover:bg-violet-200 dark:bg-violet-900 dark:text-violet-300"
                              variant="outline"
                            >
                              {item.badge}
                            </Badge>
                          )}
                          <ChevronDown
                            className={cn(
                              "size-4 text-gray-500 transition-transform dark:text-gray-400",
                              openSubMenus[item.key] && "rotate-180",
                            )}
                          />
                        </div>
                      )}
                    </button>
                    {!iconOnly && openSubMenus[item.key] && (
                      <div className="mt-1 space-y-1 pl-10">
                        {item.subItems.map((subItem) => (
                          <button
                            key={subItem.key}
                            className={cn(
                              "w-full rounded-lg px-3 py-2 text-left text-sm transition-colors",
                              "text-gray-700 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-800",
                              subItem.isActive &&
                                "bg-gray-100 font-medium text-violet-600 dark:bg-gray-800 dark:text-violet-400",
                            )}
                          >
                            {subItem.label}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </nav>
        </div>

        {/* 사이드바 푸터 */}
        <div className="border-t p-4 dark:border-gray-800">
          {!iconOnly ? (
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Avatar>
                  <AvatarImage src="/abstract-geometric-shapes.png" />
                  <AvatarFallback>사용자</AvatarFallback>
                </Avatar>
                <div>
                  <p className="text-sm font-medium text-gray-900 dark:text-white">홍길동</p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">관리자</p>
                </div>
              </div>
              <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
                <LogOut className="size-4" />
              </Button>
            </div>
          ) : (
            <div className="flex justify-center">
              <Avatar>
                <AvatarImage src="/abstract-geometric-shapes.png" />
                <AvatarFallback>사용자</AvatarFallback>
              </Avatar>
            </div>
          )}
        </div>
      </div>

      {/* 메인 콘텐츠 */}
      <div className="flex flex-1 flex-col">
        <header className="flex h-16 items-center justify-between border-b bg-white px-6 dark:border-gray-800 dark:bg-gray-900">
          <div className="flex items-center gap-2">
            {collapsed && (
              <Button variant="ghost" size="icon" onClick={() => setCollapsed(false)}>
                <Menu className="size-5" />
              </Button>
            )}
            {!collapsed && (
              <Button variant="ghost" size="icon" onClick={() => setCollapsed(true)}>
                <X className="size-5" />
              </Button>
            )}
            <h1 className="text-xl font-semibold text-gray-900 dark:text-white">모던 미니멀 사이드바</h1>
          </div>
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon" className="rounded-full">
              <Bell className="size-5" />
            </Button>
            <Button variant="ghost" size="icon" className="rounded-full">
              <Search className="size-5" />
            </Button>
            <Avatar>
              <AvatarImage src="/abstract-geometric-shapes.png" />
              <AvatarFallback>사용자</AvatarFallback>
            </Avatar>
          </div>
        </header>
        <main className="flex-1 overflow-auto p-6">
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="rounded-xl border bg-white p-6 shadow-sm dark:border-gray-800 dark:bg-gray-900">
                <h3 className="mb-4 text-lg font-medium">카드 {i + 1}</h3>
                <p className="text-gray-500 dark:text-gray-400">
                  여기에 콘텐츠가 표시됩니다. 이 부분은 실제 데이터로 대체될 수 있습니다.
                </p>
              </div>
            ))}
          </div>
        </main>
      </div>
    </div>
  )
}

// 모던 사이드바 2: 그라데이션 디자인
export function ModernSidebar2() {
  const [collapsed, setCollapsed] = React.useState(false)
  const [iconOnly, setIconOnly] = React.useState(false)
  const [activeMenu, setActiveMenu] = React.useState("dashboard")
  const [openSubMenus, setOpenSubMenus] = React.useState<Record<string, boolean>>({
    dashboard: true,
  })

  const toggleSubMenu = (key: string) => {
    setOpenSubMenus((prev) => ({
      ...prev,
      [key]: !prev[key],
    }))
  }

  const menuItems = [
    {
      key: "dashboard",
      label: "대시보드",
      icon: <LayoutDashboard className="size-4" />,
      subItems: [
        { key: "analytics", label: "분석", isActive: true },
        { key: "overview", label: "개요" },
        { key: "reports", label: "보고서" },
      ],
    },
    {
      key: "projects",
      label: "프로젝트",
      icon: <Briefcase className="size-4" />,
      subItems: [
        { key: "active", label: "진행 중" },
        { key: "archived", label: "보관됨" },
      ],
    },
    {
      key: "calendar",
      label: "캘린더",
      icon: <Calendar className="size-4" />,
      subItems: [
        { key: "month", label: "월간 보기" },
        { key: "week", label: "주간 보기" },
        { key: "day", label: "일간 보기" },
      ],
    },
    {
      key: "analytics",
      label: "분석",
      icon: <BarChart3 className="size-4" />,
      subItems: [
        { key: "performance", label: "성과" },
        { key: "traffic", label: "트래픽" },
        { key: "conversion", label: "전환율" },
      ],
    },
    {
      key: "settings",
      label: "설정",
      icon: <Settings className="size-4" />,
      subItems: [
        { key: "profile", label: "프로필" },
        { key: "security", label: "보안" },
        { key: "preferences", label: "환경설정" },
      ],
    },
  ]

  return (
    <div className="flex h-screen w-full bg-gray-50 dark:bg-gray-950">
      <div
        className={cn(
          "relative flex flex-col bg-gradient-to-b from-blue-600 to-indigo-800 transition-all duration-300",
          collapsed ? "w-0" : iconOnly ? "w-16" : "w-64",
        )}
      >
        {/* 사이드바 헤더 */}
        <div className="flex h-16 items-center justify-between border-b border-white/10 px-4">
          {!iconOnly && !collapsed && (
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-full bg-white">
                <Globe className="size-4 text-blue-600" />
              </div>
              <span className="font-semibold text-white">글로벌 앱</span>
            </div>
          )}
          {iconOnly && !collapsed && (
            <div className="mx-auto flex h-8 w-8 items-center justify-center rounded-full bg-white">
              <Globe className="size-4 text-blue-600" />
            </div>
          )}
          {!collapsed && (
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8 rounded-full text-white/70 hover:bg-white/10 hover:text-white"
              onClick={() => setIconOnly(!iconOnly)}
            >
              {iconOnly ? <ChevronRight className="size-4" /> : <Menu className="size-4" />}
            </Button>
          )}
        </div>

        {/* 메뉴 아이템 */}
        <div className="flex-1 overflow-y-auto py-4">
          <nav className="px-3">
            {/* 홈 메뉴 */}
            <div className="mb-4">
              <button
                className={cn(
                  "flex w-full items-center rounded-lg px-3 py-2.5 text-sm font-medium transition-colors",
                  "text-white hover:bg-white/10",
                  "bg-white/10",
                )}
              >
                <Home className="mr-3 size-4" />
                {!iconOnly && <span>홈</span>}
              </button>
            </div>

            {/* 메뉴 섹션 */}
            <div className="mb-4">
              {!iconOnly && <h3 className="mb-2 px-3 text-xs font-semibold uppercase text-white/70">메뉴</h3>}
              <div className="space-y-1">
                {menuItems.map((item) => (
                  <div key={item.key}>
                    <button
                      className={cn(
                        "flex w-full items-center justify-between rounded-lg px-3 py-2.5 text-sm font-medium transition-colors",
                        "text-white hover:bg-white/10",
                        activeMenu === item.key && "bg-white/10",
                      )}
                      onClick={() => {
                        setActiveMenu(item.key)
                        toggleSubMenu(item.key)
                      }}
                    >
                      <div className="flex items-center">
                        <span className="mr-3">{item.icon}</span>
                        {!iconOnly && <span>{item.label}</span>}
                      </div>
                      {!iconOnly && (
                        <ChevronDown
                          className={cn(
                            "size-4 text-white/70 transition-transform",
                            openSubMenus[item.key] && "rotate-180",
                          )}
                        />
                      )}
                    </button>
                    {!iconOnly && openSubMenus[item.key] && (
                      <div className="mt-1 space-y-1 pl-10">
                        {item.subItems.map((subItem) => (
                          <button
                            key={subItem.key}
                            className={cn(
                              "w-full rounded-lg px-3 py-2 text-left text-sm transition-colors",
                              "text-white/70 hover:bg-white/10 hover:text-white",
                              subItem.isActive && "bg-white/10 font-medium text-white",
                            )}
                          >
                            {subItem.label}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </nav>
        </div>

        {/* 사이드바 푸터 */}
        <div className="border-t border-white/10 p-4">
          {!iconOnly ? (
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Avatar className="border-2 border-white/20">
                  <AvatarImage src="/abstract-geometric-shapes.png" />
                  <AvatarFallback>사용자</AvatarFallback>
                </Avatar>
                <div>
                  <p className="text-sm font-medium text-white">홍길동</p>
                  <p className="text-xs text-white/70">관리자</p>
                </div>
              </div>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8 rounded-full text-white/70 hover:bg-white/10 hover:text-white"
              >
                <Settings className="size-4" />
              </Button>
            </div>
          ) : (
            <div className="flex justify-center">
              <Avatar className="border-2 border-white/20">
                <AvatarImage src="/abstract-geometric-shapes.png" />
                <AvatarFallback>사용자</AvatarFallback>
              </Avatar>
            </div>
          )}
        </div>
      </div>

      {/* 메인 콘텐츠 */}
      <div className="flex flex-1 flex-col">
        <header className="flex h-16 items-center justify-between border-b bg-white px-6 dark:border-gray-800 dark:bg-gray-900">
          <div className="flex items-center gap-2">
            {collapsed && (
              <Button variant="ghost" size="icon" onClick={() => setCollapsed(false)}>
                <Menu className="size-5" />
              </Button>
            )}
            {!collapsed && (
              <Button variant="ghost" size="icon" onClick={() => setCollapsed(true)}>
                <X className="size-5" />
              </Button>
            )}
            <h1 className="text-xl font-semibold text-gray-900 dark:text-white">그라데이션 사이드바</h1>
          </div>
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon" className="rounded-full">
              <Bell className="size-5" />
            </Button>
            <Button variant="ghost" size="icon" className="rounded-full">
              <Search className="size-5" />
            </Button>
            <Avatar>
              <AvatarImage src="/abstract-geometric-shapes.png" />
              <AvatarFallback>사용자</AvatarFallback>
            </Avatar>
          </div>
        </header>
        <main className="flex-1 overflow-auto p-6">
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="rounded-xl border bg-white p-6 shadow-sm dark:border-gray-800 dark:bg-gray-900">
                <h3 className="mb-4 text-lg font-medium">카드 {i + 1}</h3>
                <p className="text-gray-500 dark:text-gray-400">
                  여기에 콘텐츠가 표시됩니다. 이 부분은 실제 데이터로 대체될 수 있습니다.
                </p>
              </div>
            ))}
          </div>
        </main>
      </div>
    </div>
  )
}

// 모던 사이드바 3: 둥근 모서리 디자인
export function ModernSidebar3() {
  const [collapsed, setCollapsed] = React.useState(false)
  const [iconOnly, setIconOnly] = React.useState(false)
  const [activeMenu, setActiveMenu] = React.useState("dashboard")
  const [openSubMenus, setOpenSubMenus] = React.useState<Record<string, boolean>>({
    dashboard: true,
  })

  const toggleSubMenu = (key: string) => {
    setOpenSubMenus((prev) => ({
      ...prev,
      [key]: !prev[key],
    }))
  }

  const menuItems = [
    {
      key: "dashboard",
      label: "대시보드",
      icon: <LayoutDashboard className="size-4" />,
      subItems: [
        { key: "analytics", label: "분석", isActive: true },
        { key: "overview", label: "개요" },
        { key: "reports", label: "보고서" },
      ],
    },
    {
      key: "projects",
      label: "프로젝트",
      icon: <Briefcase className="size-4" />,
      subItems: [
        { key: "active", label: "진행 중" },
        { key: "archived", label: "보관됨" },
      ],
    },
    {
      key: "bookmarks",
      label: "북마크",
      icon: <Bookmark className="size-4" />,
      subItems: [
        { key: "recent", label: "최근 항목" },
        { key: "saved", label: "저장된 항목" },
      ],
    },
    {
      key: "messages",
      label: "메시지",
      icon: <MessageSquare className="size-4" />,
      subItems: [
        { key: "inbox", label: "받은 메시지" },
        { key: "sent", label: "보낸 메시지" },
        { key: "drafts", label: "임시 보관함" },
      ],
    },
    {
      key: "settings",
      label: "설정",
      icon: <Settings className="size-4" />,
      subItems: [
        { key: "profile", label: "프로필" },
        { key: "security", label: "보안" },
        { key: "preferences", label: "환경설정" },
      ],
    },
  ]

  return (
    <div className="flex h-screen w-full bg-gray-100 dark:bg-gray-950">
      <div
        className={cn(
          "relative m-4 flex flex-col rounded-3xl bg-white transition-all duration-300 dark:bg-gray-900",
          collapsed ? "w-0" : iconOnly ? "w-20" : "w-72",
        )}
      >
        {/* 사이드바 헤더 */}
        <div className="flex h-20 items-center justify-between px-6">
          {!iconOnly && !collapsed && (
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-teal-500">
                <Layers className="size-5 text-white" />
              </div>
              <span className="text-lg font-semibold text-gray-900 dark:text-white">Dashify</span>
            </div>
          )}
          {iconOnly && !collapsed && (
            <div className="mx-auto flex h-10 w-10 items-center justify-center rounded-xl bg-teal-500">
              <Layers className="size-5 text-white" />
            </div>
          )}
          {!collapsed && (
            <Button
              variant="ghost"
              size="icon"
              className="h-9 w-9 rounded-full text-gray-500 hover:bg-gray-100 hover:text-gray-900 dark:text-gray-400 dark:hover:bg-gray-800 dark:hover:text-white"
              onClick={() => setIconOnly(!iconOnly)}
            >
              {iconOnly ? <ChevronRight className="size-4" /> : <Menu className="size-4" />}
            </Button>
          )}
        </div>

        {/* 메뉴 아이템 */}
        <div className="flex-1 overflow-y-auto px-4 py-6">
          <nav>
            {/* 홈 메뉴 */}
            <div className="mb-6">
              <button
                className={cn(
                  "flex w-full items-center rounded-xl px-4 py-3 text-sm font-medium transition-colors",
                  "text-gray-900 hover:bg-gray-100 dark:text-white dark:hover:bg-gray-800",
                  "bg-gray-100 dark:bg-gray-800",
                )}
              >
                <Home className={cn("size-5", iconOnly ? "mx-auto" : "mr-3")} />
                {!iconOnly && <span>홈</span>}
              </button>
            </div>

            {/* 메뉴 섹션 */}
            <div className="mb-6">
              {!iconOnly && (
                <h3 className="mb-3 px-4 text-xs font-semibold uppercase text-gray-500 dark:text-gray-400">메뉴</h3>
              )}
              <div className="space-y-2">
                {menuItems.map((item) => (
                  <div key={item.key} className="mb-2">
                    <button
                      className={cn(
                        "flex w-full items-center justify-between rounded-xl px-4 py-3 text-sm font-medium transition-colors",
                        "text-gray-900 hover:bg-gray-100 dark:text-white dark:hover:bg-gray-800",
                        activeMenu === item.key && "bg-gray-100 dark:bg-gray-800",
                      )}
                      onClick={() => {
                        setActiveMenu(item.key)
                        toggleSubMenu(item.key)
                      }}
                    >
                      <div className="flex items-center">
                        <span className={cn("size-5", iconOnly ? "mx-auto" : "mr-3")}>{item.icon}</span>
                        {!iconOnly && <span>{item.label}</span>}
                      </div>
                      {!iconOnly && (
                        <ChevronDown
                          className={cn(
                            "size-4 text-gray-500 transition-transform dark:text-gray-400",
                            openSubMenus[item.key] && "rotate-180",
                          )}
                        />
                      )}
                    </button>
                    {!iconOnly && openSubMenus[item.key] && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: "auto", opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.2 }}
                        className="mt-2 overflow-hidden pl-12"
                      >
                        <div className="space-y-1">
                          {item.subItems.map((subItem) => (
                            <button
                              key={subItem.key}
                              className={cn(
                                "w-full rounded-lg px-3 py-2 text-left text-sm transition-colors",
                                "text-gray-700 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-800",
                                subItem.isActive &&
                                  "bg-teal-50 font-medium text-teal-600 dark:bg-teal-900/20 dark:text-teal-400",
                              )}
                            >
                              {subItem.label}
                            </button>
                          ))}
                        </div>
                      </motion.div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </nav>
        </div>

        {/* 사이드바 푸터 */}
        <div className="p-4">
          {!iconOnly ? (
            <div className="flex items-center gap-3 rounded-xl bg-gray-50 p-3 dark:bg-gray-800">
              <Avatar>
                <AvatarImage src="/abstract-geometric-shapes.png" />
                <AvatarFallback>사용자</AvatarFallback>
              </Avatar>
              <div className="flex-1">
                <p className="text-sm font-medium text-gray-900 dark:text-white">홍길동</p>
                <p className="text-xs text-gray-500 dark:text-gray-400">관리자</p>
              </div>
              <Button variant="ghost" size="icon" className="h-8 w-8 rounded-lg">
                <LogOut className="size-4" />
              </Button>
            </div>
          ) : (
            <div className="flex justify-center">
              <Avatar>
                <AvatarImage src="/abstract-geometric-shapes.png" />
                <AvatarFallback>사용자</AvatarFallback>
              </Avatar>
            </div>
          )}
        </div>
      </div>

      {/* 메인 콘텐츠 */}
      <div className="flex flex-1 flex-col">
        <header className="flex h-16 items-center justify-between border-b bg-white px-6 dark:border-gray-800 dark:bg-gray-900">
          <div className="flex items-center gap-2">
            {collapsed && (
              <Button variant="ghost" size="icon" onClick={() => setCollapsed(false)}>
                <Menu className="size-5" />
              </Button>
            )}
            {!collapsed && (
              <Button variant="ghost" size="icon" onClick={() => setCollapsed(true)}>
                <X className="size-5" />
              </Button>
            )}
            <h1 className="text-xl font-semibold text-gray-900 dark:text-white">둥근 모서리 사이드바</h1>
          </div>
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon" className="rounded-full">
              <Bell className="size-5" />
            </Button>
            <Button variant="ghost" size="icon" className="rounded-full">
              <Search className="size-5" />
            </Button>
            <Avatar>
              <AvatarImage src="/abstract-geometric-shapes.png" />
              <AvatarFallback>사용자</AvatarFallback>
            </Avatar>
          </div>
        </header>
        <main className="flex-1 overflow-auto p-6">
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="rounded-xl border bg-white p-6 shadow-sm dark:border-gray-800 dark:bg-gray-900">
                <h3 className="mb-4 text-lg font-medium">카드 {i + 1}</h3>
                <p className="text-gray-500 dark:text-gray-400">
                  여기에 콘텐츠가 표시됩니다. 이 부분은 실제 데이터로 대체될 수 있습니다.
                </p>
              </div>
            ))}
          </div>
        </main>
      </div>
    </div>
  )
}
