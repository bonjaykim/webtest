"use client"

import * as React from "react"
import { Home, ChevronLeft, ChevronRight, Settings, FileText, Menu, X, Briefcase, LayoutDashboard } from "lucide-react"

import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarMenuSub,
  SidebarMenuSubButton,
  SidebarMenuSubItem,
  SidebarRail,
  SidebarProvider,
  SidebarInset,
  SidebarFooter,
} from "@/components/ui/sidebar"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

export function SidebarVariation3() {
  const [collapsed, setCollapsed] = React.useState(false)
  const [iconOnly, setIconOnly] = React.useState(false)

  const menuData = [
    {
      title: "대시보드",
      icon: <LayoutDashboard className="size-4" />,
      url: "#",
      items: [
        { title: "개요", url: "#" },
        { title: "분석", url: "#" },
      ],
    },
    {
      title: "프로젝트",
      icon: <Briefcase className="size-4" />,
      url: "#",
      items: [
        { title: "모든 프로젝트", url: "#" },
        { title: "최근 프로젝트", url: "#" },
      ],
    },
    {
      title: "문서",
      icon: <FileText className="size-4" />,
      url: "#",
      items: [
        { title: "모든 문서", url: "#" },
        { title: "공유 문서", url: "#" },
      ],
    },
    {
      title: "설정",
      icon: <Settings className="size-4" />,
      url: "#",
      items: [
        { title: "일반", url: "#" },
        { title: "보안", url: "#" },
      ],
    },
  ]

  return (
    <SidebarProvider>
      <Sidebar
        className={cn(
          "transition-all duration-300 bg-gray-900 text-gray-100",
          collapsed ? "w-0" : iconOnly ? "w-16" : "w-64",
        )}
      >
        <SidebarHeader className="flex justify-between items-center border-b border-gray-800">
          <SidebarMenu>
            <SidebarMenuItem>
              <SidebarMenuButton size="lg" asChild>
                <a href="#" className="flex items-center">
                  <div className="flex aspect-square size-8 items-center justify-center rounded-lg bg-blue-600 text-white">
                    <Home className="size-4" />
                  </div>
                  {!iconOnly && <span className="ml-2 font-semibold">홈</span>}
                </a>
              </SidebarMenuButton>
            </SidebarMenuItem>
          </SidebarMenu>
          {!collapsed && (
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIconOnly(!iconOnly)}
              className="mr-2 text-gray-400 hover:text-gray-100 hover:bg-gray-800"
            >
              {iconOnly ? <ChevronRight className="size-4" /> : <ChevronLeft className="size-4" />}
            </Button>
          )}
        </SidebarHeader>
        <SidebarContent>
          <SidebarGroup>
            <SidebarMenu>
              {menuData.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton asChild className="text-gray-300 hover:text-white hover:bg-gray-800">
                    <a href={item.url} className="flex items-center">
                      {item.icon}
                      {!iconOnly && <span className="ml-2">{item.title}</span>}
                    </a>
                  </SidebarMenuButton>
                  {!iconOnly && item.items?.length > 0 && (
                    <SidebarMenuSub>
                      {item.items.map((subItem) => (
                        <SidebarMenuSubItem key={subItem.title}>
                          <SidebarMenuSubButton asChild className="text-gray-400 hover:text-white">
                            <a href={subItem.url}>{subItem.title}</a>
                          </SidebarMenuSubButton>
                        </SidebarMenuSubItem>
                      ))}
                    </SidebarMenuSub>
                  )}
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroup>
        </SidebarContent>
        <SidebarFooter className="border-t border-gray-800">
          {!iconOnly ? (
            <div className="p-4">
              <div className="flex items-center gap-3">
                <Avatar>
                  <AvatarImage src="/diverse-avatars.png" />
                  <AvatarFallback>사용자</AvatarFallback>
                </Avatar>
                <div className="flex flex-col">
                  <span className="text-sm font-medium">홍길동</span>
                  <span className="text-xs text-gray-400">관리자</span>
                </div>
              </div>
            </div>
          ) : (
            <div className="p-2 flex justify-center">
              <Avatar className="size-8">
                <AvatarImage src="/diverse-avatars.png" />
                <AvatarFallback>사용자</AvatarFallback>
              </Avatar>
            </div>
          )}
        </SidebarFooter>
        <SidebarRail className="bg-gray-800" />
      </Sidebar>
      <SidebarInset className="flex-1">
        <header className="flex h-16 shrink-0 items-center gap-2 border-b px-4">
          {collapsed ? (
            <Button variant="ghost" size="icon" onClick={() => setCollapsed(false)}>
              <Menu className="size-4" />
            </Button>
          ) : (
            <Button variant="ghost" size="icon" onClick={() => setCollapsed(true)}>
              <X className="size-4" />
            </Button>
          )}
          <h1 className="text-xl font-semibold">변형 3: 다크 테마</h1>
        </header>
        <div className="p-4">
          <div className="rounded-lg border p-4">
            <h2 className="text-lg font-medium">콘텐츠 영역</h2>
            <p className="mt-2 text-muted-foreground">여기에 페이지 콘텐츠가 표시됩니다.</p>
          </div>
        </div>
      </SidebarInset>
    </SidebarProvider>
  )
}
