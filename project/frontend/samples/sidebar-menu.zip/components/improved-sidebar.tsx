"use client"

import * as React from "react"
import Link from "next/link"
import {
  ChevronDown,
  ChevronRight,
  Settings,
  Menu,
  X,
  LayoutDashboard,
  Briefcase,
  MessageSquare,
  Bell,
  Search,
  Layers,
  Users,
  FileText,
  ChevronLeft,
  ShoppingCart,
  BarChart3,
  LineChart,
  PieChart,
  Clock,
  Archive,
  UserCog,
  Shield,
  UserPlus,
  Package,
  Inbox,
  Send,
  PenTool,
  FileBarChart,
  FileSpreadsheet,
  FileTextIcon as FileText2,
  Calendar,
  Lock,
  Sliders,
} from "lucide-react"
import { motion } from "framer-motion"

import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"
import { Input } from "@/components/ui/input"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"

interface MenuItemIcon {
  icon?: React.ReactNode
}

interface ThirdLevelMenuItem extends MenuItemIcon {
  key: string
  label: string
  href?: string
}

interface SecondLevelMenuItem extends MenuItemIcon {
  key: string
  label: string
  hasChildren?: boolean
  children?: ThirdLevelMenuItem[]
  isActive?: boolean
  href?: string
}

interface MainMenuItem extends MenuItemIcon {
  key: string
  label: string
  icon: React.ReactNode
  subItems: SecondLevelMenuItem[]
}

export function ImprovedSidebar() {
  const [collapsed, setCollapsed] = React.useState(false)
  const [iconOnly, setIconOnly] = React.useState(false)
  const [activeMenu, setActiveMenu] = React.useState("dashboard")
  // 첫 메뉴를 모두 펼친 상태로 초기화
  const [openSubMenus, setOpenSubMenus] = React.useState<Record<string, boolean>>({
    dashboard: true,
    projects: true,
    users: true,
    products: true,
    messages: true,
    documents: true,
    settings: true,
  })
  const [openThirdLevelMenus, setOpenThirdLevelMenus] = React.useState<Record<string, boolean>>({
    active: true,
    archived: true,
    permissions: true,
    reports: true,
  })

  const toggleSubMenu = (key: string) => {
    setOpenSubMenus((prev) => ({
      ...prev,
      [key]: !prev[key],
    }))
  }

  const toggleThirdLevelMenu = (key: string) => {
    setOpenThirdLevelMenus((prev) => ({
      ...prev,
      [key]: !prev[key],
    }))
  }

  // 2단계와 3단계가 혼합된 메뉴 데이터 (아이콘 추가)
  const menuItems: MainMenuItem[] = [
    {
      key: "dashboard",
      label: "대시보드",
      icon: <LayoutDashboard className="size-4" />,
      subItems: [
        { key: "analytics", label: "분석", isActive: true, icon: <BarChart3 className="size-4" />, href: "/home" },
        { key: "overview", label: "개요", icon: <PieChart className="size-4" />, href: "/home" },
        { key: "reports", label: "보고서", icon: <LineChart className="size-4" />, href: "/home" },
      ],
    },
    {
      key: "projects",
      label: "프로젝트",
      icon: <Briefcase className="size-4" />,
      subItems: [
        {
          key: "active",
          label: "진행 중",
          icon: <Clock className="size-4" />,
          hasChildren: true,
          children: [
            { key: "frontend", label: "프론트엔드", icon: <PenTool className="size-3.5" />, href: "/home" },
            { key: "backend", label: "백엔드", icon: <FileBarChart className="size-3.5" />, href: "/home" },
            { key: "design", label: "디자인", icon: <FileSpreadsheet className="size-3.5" />, href: "/home" },
          ],
        },
        {
          key: "archived",
          label: "보관됨",
          icon: <Archive className="size-4" />,
          hasChildren: true,
          children: [
            { key: "2023", label: "2023년", icon: <Calendar className="size-3.5" />, href: "/home" },
            { key: "2022", label: "2022년", icon: <Calendar className="size-3.5" />, href: "/home" },
          ],
        },
      ],
    },
    {
      key: "users",
      label: "사용자 관리",
      icon: <Users className="size-4" />,
      subItems: [
        { key: "team", label: "팀 관리", icon: <UserPlus className="size-4" />, href: "/home" },
        {
          key: "permissions",
          label: "권한 설정",
          icon: <UserCog className="size-4" />,
          hasChildren: true,
          children: [
            { key: "roles", label: "역할 관리", icon: <Shield className="size-3.5" />, href: "/home" },
            { key: "access", label: "접근 권한", icon: <Lock className="size-3.5" />, href: "/home" },
            { key: "groups", label: "그룹 관리", icon: <Users className="size-3.5" />, href: "/home" },
          ],
        },
      ],
    },
    {
      key: "products",
      label: "상품 관리",
      icon: <ShoppingCart className="size-4" />,
      subItems: [
        { key: "list", label: "상품 목록", icon: <Package className="size-4" />, href: "/home" },
        { key: "inventory", label: "재고 관리", icon: <Package className="size-4" />, href: "/home" },
      ],
    },
    {
      key: "messages",
      label: "메시지",
      icon: <MessageSquare className="size-4" />,
      subItems: [
        { key: "inbox", label: "받은 메시지", icon: <Inbox className="size-4" />, href: "/home" },
        { key: "sent", label: "보낸 메시지", icon: <Send className="size-4" />, href: "/home" },
        { key: "drafts", label: "임시 보관함", icon: <PenTool className="size-4" />, href: "/home" },
      ],
    },
    {
      key: "documents",
      label: "문서",
      icon: <FileText className="size-4" />,
      subItems: [
        {
          key: "reports",
          label: "보고서",
          icon: <FileText2 className="size-4" />,
          hasChildren: true,
          children: [
            { key: "monthly", label: "월간 보고서", icon: <FileBarChart className="size-3.5" />, href: "/home" },
            { key: "quarterly", label: "분기 보고서", icon: <FileBarChart className="size-3.5" />, href: "/home" },
            { key: "annual", label: "연간 보고서", icon: <FileBarChart className="size-3.5" />, href: "/home" },
          ],
        },
        { key: "contracts", label: "계약서", icon: <FileText2 className="size-4" />, href: "/home" },
      ],
    },
    {
      key: "settings",
      label: "설정",
      icon: <Settings className="size-4" />,
      subItems: [
        { key: "profile", label: "프로필", icon: <Users className="size-4" />, href: "/home" },
        { key: "security", label: "보안", icon: <Shield className="size-4" />, href: "/home" },
        { key: "preferences", label: "환경설정", icon: <Sliders className="size-4" />, href: "/home" },
      ],
    },
  ]

  return (
    <TooltipProvider delayDuration={300}>
      <div className="flex h-screen w-full bg-gray-100 dark:bg-gray-950">
        <div
          className={cn(
            "relative flex flex-col bg-white transition-all duration-300 dark:bg-gray-900",
            collapsed ? "w-0" : iconOnly ? "w-16" : "w-72",
          )}
        >
          {/* 사이드바 헤더 */}
          <div className="flex h-16 items-center px-6">
            {!iconOnly && !collapsed && (
              <a href="/home" className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-teal-500">
                  <Layers className="size-5 text-white" />
                </div>
                <span className="text-lg font-semibold text-gray-900 dark:text-white">Dashify</span>
              </a>
            )}
            {iconOnly && !collapsed && (
              <a href="/home" className="mx-auto">
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-teal-500">
                  <Layers className="size-5 text-white" />
                </div>
              </a>
            )}
          </div>

          {/* 검색 */}
          {!collapsed && !iconOnly && (
            <div className="px-4 py-3">
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 size-4 text-gray-500 dark:text-gray-400" />
                <Input
                  type="search"
                  placeholder="검색..."
                  className="w-full rounded-lg border border-gray-200 bg-gray-50 pl-9 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-300"
                />
              </div>
            </div>
          )}

          {/* 메뉴 아이템 */}
          <div className="flex-1 overflow-y-auto px-4 py-6">
            <nav>
              {/* 메뉴 섹션 */}
              <div className="mb-6">
                {!iconOnly && (
                  <h3 className="mb-3 px-4 text-xs font-semibold uppercase text-gray-500 dark:text-gray-400">메뉴</h3>
                )}
                <div className="space-y-2">
                  {menuItems.map((item) => (
                    <div key={item.key} className="mb-2">
                      {iconOnly ? (
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <button
                              className={cn(
                                "flex w-full items-center justify-center rounded-xl px-4 py-3 text-sm font-medium transition-colors",
                                "text-gray-900 hover:bg-gray-100 dark:text-white dark:hover:bg-gray-800",
                                activeMenu === item.key && "bg-gray-100 dark:bg-gray-800",
                              )}
                              onClick={() => {
                                setActiveMenu(item.key)
                              }}
                            >
                              <span className="size-5">{item.icon}</span>
                            </button>
                          </TooltipTrigger>
                          <TooltipContent side="right">{item.label}</TooltipContent>
                        </Tooltip>
                      ) : (
                        <button
                          className={cn(
                            "flex w-full items-center justify-between rounded-xl px-4 py-3 text-sm font-medium transition-colors",
                            "text-gray-900 hover:bg-gray-100 dark:text-white dark:hover:bg-gray-800",
                            activeMenu === item.key && "bg-gray-100 dark:bg-gray-800",
                          )}
                          onClick={() => {
                            setActiveMenu(item.key)
                            toggleSubMenu(item.key)
                          }}
                        >
                          <div className="flex items-center">
                            <span className="mr-3 size-5">{item.icon}</span>
                            <span>{item.label}</span>
                          </div>
                          <ChevronDown
                            className={cn(
                              "size-4 text-gray-500 transition-transform dark:text-gray-400",
                              openSubMenus[item.key] && "rotate-180",
                            )}
                          />
                        </button>
                      )}
                      {!iconOnly && openSubMenus[item.key] && (
                        <motion.div
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: "auto", opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          transition={{ duration: 0.2 }}
                          className="mt-2 overflow-hidden pl-12"
                        >
                          <div className="space-y-1">
                            {item.subItems.map((subItem) => (
                              <div key={subItem.key}>
                                {subItem.hasChildren ? (
                                  <div>
                                    <button
                                      className={cn(
                                        "flex w-full items-center justify-between rounded-lg px-3 py-2 text-left text-sm transition-colors",
                                        "text-gray-700 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-800",
                                      )}
                                      onClick={() => toggleThirdLevelMenu(subItem.key)}
                                    >
                                      <div className="flex items-center">
                                        {subItem.icon && <span className="mr-2">{subItem.icon}</span>}
                                        <span>{subItem.label}</span>
                                      </div>
                                      <ChevronRight
                                        className={cn(
                                          "size-3.5 text-gray-500 transition-transform dark:text-gray-400",
                                          openThirdLevelMenus[subItem.key] && "rotate-90",
                                        )}
                                      />
                                    </button>
                                    {openThirdLevelMenus[subItem.key] && (
                                      <motion.div
                                        initial={{ height: 0, opacity: 0 }}
                                        animate={{ height: "auto", opacity: 1 }}
                                        exit={{ height: 0, opacity: 0 }}
                                        transition={{ duration: 0.2 }}
                                        className="mt-1 pl-4"
                                      >
                                        <div className="space-y-1 border-l pl-2">
                                          {subItem.children?.map((child) => (
                                            <Link
                                              key={child.key}
                                              href={child.href || "/home"}
                                              className="flex w-full items-center rounded-lg px-3 py-1.5 text-left text-xs text-gray-600 transition-colors hover:bg-gray-100 hover:text-gray-900 dark:text-gray-400 dark:hover:bg-gray-800 dark:hover:text-gray-200"
                                            >
                                              {child.icon && <span className="mr-2">{child.icon}</span>}
                                              <span>{child.label}</span>
                                            </Link>
                                          ))}
                                        </div>
                                      </motion.div>
                                    )}
                                  </div>
                                ) : (
                                  <Link
                                    href={subItem.href || "/home"}
                                    className={cn(
                                      "flex w-full items-center rounded-lg px-3 py-2 text-left text-sm transition-colors",
                                      "text-gray-700 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-800",
                                      subItem.isActive &&
                                        "bg-teal-50 font-medium text-teal-600 dark:bg-teal-900/20 dark:text-teal-400",
                                    )}
                                  >
                                    <div className="flex items-center">
                                      {subItem.icon && <span className="mr-2">{subItem.icon}</span>}
                                      <span>{subItem.label}</span>
                                    </div>
                                  </Link>
                                )}
                              </div>
                            ))}
                          </div>
                        </motion.div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </nav>
          </div>

          {/* 사이드바 푸터 - 접기 버튼만 남김 */}
          <div className="border-t p-4 dark:border-gray-800">
            <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full" onClick={() => setIconOnly(!iconOnly)}>
              {iconOnly ? <ChevronRight className="size-4" /> : <ChevronLeft className="size-4" />}
            </Button>
          </div>
        </div>

        {/* 메인 콘텐츠 */}
        <div className="flex flex-1 flex-col">
          <header className="flex h-16 items-center justify-between border-b bg-white px-6 dark:border-gray-800 dark:bg-gray-900">
            <div className="flex items-center gap-2">
              {collapsed && (
                <Button variant="ghost" size="icon" onClick={() => setCollapsed(false)}>
                  <Menu className="size-5" />
                </Button>
              )}
              {!collapsed && (
                <Button variant="ghost" size="icon" onClick={() => setCollapsed(true)}>
                  <X className="size-5" />
                </Button>
              )}
              <h1 className="text-xl font-semibold text-gray-900 dark:text-white">개선된 사이드바</h1>
            </div>
            <div className="flex items-center gap-3">
              <Button variant="ghost" size="icon" className="rounded-full">
                <Bell className="size-5" />
              </Button>
              <Button variant="ghost" size="icon" className="rounded-full">
                <Search className="size-5" />
              </Button>
            </div>
          </header>
          <main className="flex-1 overflow-auto p-6">
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {Array.from({ length: 6 }).map((_, i) => (
                <div key={i} className="rounded-xl border bg-white p-6 shadow-sm dark:border-gray-800 dark:bg-gray-900">
                  <h3 className="mb-4 text-lg font-medium">카드 {i + 1}</h3>
                  <p className="text-gray-500 dark:text-gray-400">
                    여기에 콘텐츠가 표시됩니다. 이 부분은 실제 데이터로 대체될 수 있습니다.
                  </p>
                </div>
              ))}
            </div>
          </main>
        </div>
      </div>
    </TooltipProvider>
  )
}
