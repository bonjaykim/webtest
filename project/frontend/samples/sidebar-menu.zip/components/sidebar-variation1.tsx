"use client"

import * as React from "react"
import { Layers, ChevronLeft, ChevronRight, Settings, Users, MessageSquare, Menu, X } from "lucide-react"

import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarMenuSub,
  SidebarMenuSubButton,
  SidebarMenuSubItem,
  SidebarRail,
  SidebarProvider,
  SidebarInset,
  SidebarFooter,
} from "@/components/ui/sidebar"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { LayoutDashboard } from "lucide-react"

export function SidebarVariation1() {
  const [collapsed, setCollapsed] = React.useState(false)
  const [iconOnly, setIconOnly] = React.useState(false)

  const menuData = [
    {
      title: "대시보드",
      icon: <LayoutDashboard className="size-4" />,
      url: "#",
      badge: "신규",
      items: [
        { title: "개요", url: "#" },
        { title: "분석", url: "#" },
      ],
    },
    {
      title: "사용자",
      icon: <Users className="size-4" />,
      url: "#",
      badge: "23",
      items: [
        { title: "프로필", url: "#" },
        { title: "설정", url: "#" },
      ],
    },
    {
      title: "메시지",
      icon: <MessageSquare className="size-4" />,
      url: "#",
      badge: "5",
      items: [
        { title: "받은 메시지", url: "#" },
        { title: "보낸 메시지", url: "#" },
      ],
    },
    {
      title: "설정",
      icon: <Settings className="size-4" />,
      url: "#",
      items: [
        { title: "계정", url: "#" },
        { title: "보안", url: "#" },
      ],
    },
  ]

  return (
    <SidebarProvider>
      <Sidebar
        className={cn(
          "transition-all duration-300 bg-slate-50 dark:bg-slate-950",
          collapsed ? "w-0" : iconOnly ? "w-16" : "w-64",
        )}
      >
        <SidebarHeader className="flex justify-between items-center">
          <SidebarMenu>
            <SidebarMenuItem>
              <SidebarMenuButton size="lg" asChild>
                <a href="#" className="flex items-center">
                  <div className="flex aspect-square size-8 items-center justify-center rounded-lg bg-purple-600 text-white">
                    <Layers className="size-4" />
                  </div>
                  {!iconOnly && <span className="ml-2 font-semibold">워크스페이스</span>}
                </a>
              </SidebarMenuButton>
            </SidebarMenuItem>
          </SidebarMenu>
          {!collapsed && (
            <Button variant="ghost" size="icon" onClick={() => setIconOnly(!iconOnly)} className="mr-2">
              {iconOnly ? <ChevronRight className="size-4" /> : <ChevronLeft className="size-4" />}
            </Button>
          )}
        </SidebarHeader>
        <SidebarContent>
          <SidebarGroup>
            <SidebarMenu>
              {menuData.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton asChild>
                    <a href={item.url} className="flex items-center justify-between">
                      <div className="flex items-center">
                        {item.icon}
                        {!iconOnly && <span className="ml-2">{item.title}</span>}
                      </div>
                      {!iconOnly && item.badge && (
                        <Badge
                          variant="outline"
                          className="ml-2 bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200"
                        >
                          {item.badge}
                        </Badge>
                      )}
                    </a>
                  </SidebarMenuButton>
                  {!iconOnly && item.items?.length > 0 && (
                    <SidebarMenuSub>
                      {item.items.map((subItem) => (
                        <SidebarMenuSubItem key={subItem.title}>
                          <SidebarMenuSubButton asChild>
                            <a href={subItem.url}>{subItem.title}</a>
                          </SidebarMenuSubButton>
                        </SidebarMenuSubItem>
                      ))}
                    </SidebarMenuSub>
                  )}
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroup>
        </SidebarContent>
        <SidebarFooter>
          {!iconOnly ? (
            <div className="p-4">
              <div className="flex items-center gap-3">
                <Avatar>
                  <AvatarImage src="/diverse-avatars.png" />
                  <AvatarFallback>사용자</AvatarFallback>
                </Avatar>
                <div className="flex flex-col">
                  <span className="text-sm font-medium">홍길동</span>
                  <span className="text-xs text-muted-foreground">관리자</span>
                </div>
              </div>
            </div>
          ) : (
            <div className="p-2 flex justify-center">
              <Avatar className="size-8">
                <AvatarImage src="/diverse-avatars.png" />
                <AvatarFallback>사용자</AvatarFallback>
              </Avatar>
            </div>
          )}
        </SidebarFooter>
        <SidebarRail />
      </Sidebar>
      <SidebarInset className="flex-1">
        <header className="flex h-16 shrink-0 items-center gap-2 border-b px-4">
          {collapsed ? (
            <Button variant="ghost" size="icon" onClick={() => setCollapsed(false)}>
              <Menu className="size-4" />
            </Button>
          ) : (
            <Button variant="ghost" size="icon" onClick={() => setCollapsed(true)}>
              <X className="size-4" />
            </Button>
          )}
          <h1 className="text-xl font-semibold">변형 1: 아이콘 + 텍스트 + 배지</h1>
        </header>
        <div className="p-4">
          <div className="rounded-lg border p-4">
            <h2 className="text-lg font-medium">콘텐츠 영역</h2>
            <p className="mt-2 text-muted-foreground">여기에 페이지 콘텐츠가 표시됩니다.</p>
          </div>
        </div>
      </SidebarInset>
    </SidebarProvider>
  )
}
