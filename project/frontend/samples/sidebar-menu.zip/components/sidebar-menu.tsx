"use client"

import * as React from "react"
import {
  Home,
  ChevronDown,
  ChevronRight,
  Settings,
  Users,
  ShoppingCart,
  BarChart,
  FileText,
  Mail,
  Menu,
  X,
  ChevronLeft,
} from "lucide-react"

import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarMenuSub,
  SidebarMenuSubButton,
  SidebarMenuSubItem,
  SidebarRail,
  SidebarProvider,
  SidebarInset,
} from "@/components/ui/sidebar"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

// 2단계 메뉴 데이터
const twoLevelMenuData = [
  {
    title: "대시보드",
    icon: <BarChart className="size-4" />,
    url: "#",
    items: [
      { title: "통계 개요", url: "#" },
      { title: "실시간 모니터링", url: "#" },
    ],
  },
  {
    title: "사용자 관리",
    icon: <Users className="size-4" />,
    url: "#",
    items: [
      { title: "사용자 목록", url: "#" },
      { title: "권한 설정", url: "#" },
    ],
  },
  {
    title: "상품 관리",
    icon: <ShoppingCart className="size-4" />,
    url: "#",
    items: [
      { title: "상품 목록", url: "#" },
      { title: "재고 관리", url: "#" },
    ],
  },
  {
    title: "문서",
    icon: <FileText className="size-4" />,
    url: "#",
    items: [
      { title: "보고서", url: "#" },
      { title: "계약서", url: "#" },
    ],
  },
  {
    title: "설정",
    icon: <Settings className="size-4" />,
    url: "#",
    items: [
      { title: "일반 설정", url: "#" },
      { title: "알림 설정", url: "#" },
    ],
  },
]

// 3단계 메뉴 데이터
const threeLevelMenuData = [
  {
    title: "대시보드",
    icon: <BarChart className="size-4" />,
    url: "#",
    items: [
      {
        title: "통계 개요",
        url: "#",
        subItems: [
          { title: "일간 통계", url: "#" },
          { title: "주간 통계", url: "#" },
          { title: "월간 통계", url: "#" },
        ],
      },
      {
        title: "실시간 모니터링",
        url: "#",
        subItems: [
          { title: "서버 상태", url: "#" },
          { title: "트래픽 분석", url: "#" },
        ],
      },
    ],
  },
  {
    title: "사용자 관리",
    icon: <Users className="size-4" />,
    url: "#",
    items: [
      {
        title: "사용자 목록",
        url: "#",
        subItems: [
          { title: "관리자", url: "#" },
          { title: "일반 사용자", url: "#" },
          { title: "게스트", url: "#" },
        ],
      },
      {
        title: "권한 설정",
        url: "#",
        subItems: [
          { title: "역할 관리", url: "#" },
          { title: "접근 권한", url: "#" },
        ],
      },
    ],
  },
  {
    title: "상품 관리",
    icon: <ShoppingCart className="size-4" />,
    url: "#",
    items: [
      {
        title: "상품 목록",
        url: "#",
        subItems: [
          { title: "신규 상품", url: "#" },
          { title: "인기 상품", url: "#" },
          { title: "할인 상품", url: "#" },
        ],
      },
      {
        title: "재고 관리",
        url: "#",
        subItems: [
          { title: "입고 관리", url: "#" },
          { title: "출고 관리", url: "#" },
        ],
      },
    ],
  },
  {
    title: "커뮤니케이션",
    icon: <Mail className="size-4" />,
    url: "#",
    items: [
      {
        title: "메시지",
        url: "#",
        subItems: [
          { title: "받은 메시지", url: "#" },
          { title: "보낸 메시지", url: "#" },
          { title: "임시 보관함", url: "#" },
        ],
      },
      {
        title: "알림",
        url: "#",
        subItems: [
          { title: "시스템 알림", url: "#" },
          { title: "사용자 알림", url: "#" },
        ],
      },
    ],
  },
]

// 2단계 메뉴 컴포넌트
export function TwoLevelSidebar() {
  const [collapsed, setCollapsed] = React.useState(false)
  const [iconOnly, setIconOnly] = React.useState(false)

  return (
    <SidebarProvider>
      <Sidebar className={cn("transition-all duration-300", collapsed ? "w-0" : iconOnly ? "w-16" : "w-64")}>
        <SidebarHeader className="flex justify-between items-center">
          <SidebarMenu>
            <SidebarMenuItem>
              <SidebarMenuButton size="lg" asChild>
                <a href="#" className="flex items-center">
                  <div className="flex aspect-square size-8 items-center justify-center rounded-lg bg-sidebar-primary text-sidebar-primary-foreground">
                    <Home className="size-4" />
                  </div>
                  {!iconOnly && <span className="ml-2 font-semibold">홈</span>}
                </a>
              </SidebarMenuButton>
            </SidebarMenuItem>
          </SidebarMenu>
          {!collapsed && (
            <Button variant="ghost" size="icon" onClick={() => setIconOnly(!iconOnly)} className="mr-2">
              {iconOnly ? <ChevronRight className="size-4" /> : <ChevronLeft className="size-4" />}
            </Button>
          )}
        </SidebarHeader>
        <SidebarContent>
          <SidebarGroup>
            <SidebarMenu>
              {twoLevelMenuData.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton asChild>
                    <a href={item.url} className="flex items-center">
                      {item.icon}
                      {!iconOnly && <span className="ml-2">{item.title}</span>}
                    </a>
                  </SidebarMenuButton>
                  {!iconOnly && item.items?.length > 0 && (
                    <SidebarMenuSub>
                      {item.items.map((subItem) => (
                        <SidebarMenuSubItem key={subItem.title}>
                          <SidebarMenuSubButton asChild>
                            <a href={subItem.url}>{subItem.title}</a>
                          </SidebarMenuSubButton>
                        </SidebarMenuSubItem>
                      ))}
                    </SidebarMenuSub>
                  )}
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroup>
        </SidebarContent>
        <SidebarRail />
      </Sidebar>
      <SidebarInset className="flex-1">
        <header className="flex h-16 shrink-0 items-center gap-2 border-b px-4">
          {collapsed ? (
            <Button variant="ghost" size="icon" onClick={() => setCollapsed(false)}>
              <Menu className="size-4" />
            </Button>
          ) : (
            <Button variant="ghost" size="icon" onClick={() => setCollapsed(true)}>
              <X className="size-4" />
            </Button>
          )}
          <h1 className="text-xl font-semibold">2단계 메뉴 예시</h1>
        </header>
        <div className="p-4">
          <div className="rounded-lg border p-4">
            <h2 className="text-lg font-medium">콘텐츠 영역</h2>
            <p className="mt-2 text-muted-foreground">여기에 페이지 콘텐츠가 표시됩니다.</p>
          </div>
        </div>
      </SidebarInset>
    </SidebarProvider>
  )
}

// 3단계 메뉴 컴포넌트
export function ThreeLevelSidebar() {
  const [collapsed, setCollapsed] = React.useState(false)
  const [iconOnly, setIconOnly] = React.useState(false)
  const [openSubMenus, setOpenSubMenus] = React.useState<Record<string, boolean>>({})

  const toggleSubMenu = (title: string) => {
    setOpenSubMenus((prev) => ({
      ...prev,
      [title]: !prev[title],
    }))
  }

  return (
    <SidebarProvider>
      <Sidebar className={cn("transition-all duration-300", collapsed ? "w-0" : iconOnly ? "w-16" : "w-64")}>
        <SidebarHeader className="flex justify-between items-center">
          <SidebarMenu>
            <SidebarMenuItem>
              <SidebarMenuButton size="lg" asChild>
                <a href="#" className="flex items-center">
                  <div className="flex aspect-square size-8 items-center justify-center rounded-lg bg-sidebar-primary text-sidebar-primary-foreground">
                    <Home className="size-4" />
                  </div>
                  {!iconOnly && <span className="ml-2 font-semibold">홈</span>}
                </a>
              </SidebarMenuButton>
            </SidebarMenuItem>
          </SidebarMenu>
          {!collapsed && (
            <Button variant="ghost" size="icon" onClick={() => setIconOnly(!iconOnly)} className="mr-2">
              {iconOnly ? <ChevronRight className="size-4" /> : <ChevronLeft className="size-4" />}
            </Button>
          )}
        </SidebarHeader>
        <SidebarContent>
          <SidebarGroup>
            <SidebarMenu>
              {threeLevelMenuData.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton asChild>
                    <a href={item.url} className="flex items-center">
                      {item.icon}
                      {!iconOnly && <span className="ml-2">{item.title}</span>}
                    </a>
                  </SidebarMenuButton>
                  {!iconOnly && item.items?.length > 0 && (
                    <SidebarMenuSub>
                      {item.items.map((subItem) => (
                        <SidebarMenuSubItem key={subItem.title}>
                          <div className="flex flex-col">
                            <div className="flex items-center justify-between">
                              <SidebarMenuSubButton asChild>
                                <a href={subItem.url}>{subItem.title}</a>
                              </SidebarMenuSubButton>
                              {subItem.subItems?.length > 0 && (
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  onClick={(e) => {
                                    e.preventDefault()
                                    toggleSubMenu(subItem.title)
                                  }}
                                  className="h-6 w-6"
                                >
                                  {openSubMenus[subItem.title] ? (
                                    <ChevronDown className="size-3" />
                                  ) : (
                                    <ChevronRight className="size-3" />
                                  )}
                                </Button>
                              )}
                            </div>
                            {openSubMenus[subItem.title] && subItem.subItems?.length > 0 && (
                              <div className="ml-4 mt-1 border-l pl-2">
                                {subItem.subItems.map((thirdItem) => (
                                  <a
                                    key={thirdItem.title}
                                    href={thirdItem.url}
                                    className="block py-1 text-sm text-muted-foreground hover:text-foreground"
                                  >
                                    {thirdItem.title}
                                  </a>
                                ))}
                              </div>
                            )}
                          </div>
                        </SidebarMenuSubItem>
                      ))}
                    </SidebarMenuSub>
                  )}
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroup>
        </SidebarContent>
        <SidebarRail />
      </Sidebar>
      <SidebarInset className="flex-1">
        <header className="flex h-16 shrink-0 items-center gap-2 border-b px-4">
          {collapsed ? (
            <Button variant="ghost" size="icon" onClick={() => setCollapsed(false)}>
              <Menu className="size-4" />
            </Button>
          ) : (
            <Button variant="ghost" size="icon" onClick={() => setCollapsed(true)}>
              <X className="size-4" />
            </Button>
          )}
          <h1 className="text-xl font-semibold">3단계 메뉴 예시</h1>
        </header>
        <div className="p-4">
          <div className="rounded-lg border p-4">
            <h2 className="text-lg font-medium">콘텐츠 영역</h2>
            <p className="mt-2 text-muted-foreground">여기에 페이지 콘텐츠가 표시됩니다.</p>
          </div>
        </div>
      </SidebarInset>
    </SidebarProvider>
  )
}
