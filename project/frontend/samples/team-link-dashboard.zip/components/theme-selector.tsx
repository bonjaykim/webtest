"use client"

import { useState } from "react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import EnhancedCards from "./enhanced-cards"

export default function ThemeSelector() {
  const [selectedTheme, setSelectedTheme] = useState("sapphire")

  return (
    <div className="space-y-8">
      <div className="flex justify-center">
        <div className="w-full max-w-xs">
          <Select value={selectedTheme} onValueChange={setSelectedTheme}>
            <SelectTrigger>
              <SelectValue placeholder="테마 선택" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="sapphire">Sapphire</SelectItem>
              <SelectItem value="emerald">Emerald</SelectItem>
              <SelectItem value="ruby">Ruby</SelectItem>
              <SelectItem value="amber">Amber</SelectItem>
              <SelectItem value="primary">Primary</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <EnhancedCards colorTheme={selectedTheme} />
    </div>
  )
}
