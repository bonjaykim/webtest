"use client"

import { teamData } from "@/lib/team-data"
import RotateGlowIconCombo from "./enhanced-styles/rotate-glow-icon-combo"

interface EnhancedCardsProps {
  colorTheme?: string
}

export default function EnhancedCards({ colorTheme = "sapphire" }: EnhancedCardsProps) {
  return (
    <div className="space-y-6">
      <RotateGlowIconCombo teams={teamData} colorTheme={colorTheme} />
    </div>
  )
}
