import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { getTeamLinks, chartColors } from "@/lib/utils"
import type { TeamPart } from "@/lib/team-data"
import type { LucideIcon } from "lucide-react"
import * as LucideIcons from "lucide-react"

interface IconHoverProps {
  teams: TeamPart[]
}

export default function IconHover({ teams }: IconHoverProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {teams.map((team, index) => {
        const IconComponent =
          (LucideIcons as Record<string, LucideIcon>)[team.icon.charAt(0).toUpperCase() + team.icon.slice(1)] ||
          LucideIcons.Briefcase

        const color = chartColors.primary[index % chartColors.primary.length]
        const links = getTeamLinks(team)

        return (
          <Card key={team.name} className="overflow-hidden transition-all duration-300 group relative">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-xl">{team.name}</CardTitle>
                <div className="relative">
                  {/* Icon container with animated background */}
                  <div
                    className="absolute inset-0 rounded-full transition-all duration-300 transform-gpu scale-0 group-hover:scale-100"
                    style={{ backgroundColor: color }}
                  />
                  <IconComponent
                    className="h-8 w-8 p-1 rounded-full relative z-10 transition-all duration-300 group-hover:text-white group-hover:rotate-[360deg]"
                    style={{ color }}
                  />
                </div>
              </div>
            </CardHeader>
            <CardContent className="pt-4">
              <p className="text-muted-foreground">{team.description}</p>
            </CardContent>
            <CardFooter className="flex flex-wrap gap-2 pt-0">
              {links.map((link, i) => (
                <Button key={i} variant="outline" size="sm" asChild className="text-xs transition-all duration-300">
                  <a href={link.url}>{link.label}</a>
                </Button>
              ))}
            </CardFooter>

            {/* Large decorative icon in the background */}
            <div className="absolute -bottom-12 -right-12 opacity-0 group-hover:opacity-5 transition-opacity duration-300">
              <IconComponent className="h-40 w-40" style={{ color }} />
            </div>
          </Card>
        )
      })}
    </div>
  )
}
