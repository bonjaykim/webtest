import type React from "react"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { getTeamLinks, chartColors } from "@/lib/utils"
import type { TeamPart } from "@/lib/team-data"
import type { LucideIcon } from "lucide-react"
import * as LucideIcons from "lucide-react"

interface TextHoverProps {
  teams: TeamPart[]
}

export default function TextHover({ teams }: TextHoverProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {teams.map((team, index) => {
        const IconComponent =
          (LucideIcons as Record<string, LucideIcon>)[team.icon.charAt(0).toUpperCase() + team.icon.slice(1)] ||
          LucideIcons.Briefcase

        const color = chartColors.secondary[index % chartColors.secondary.length]
        const links = getTeamLinks(team)

        return (
          <Card key={team.name} className="overflow-hidden transition-all duration-300 group">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle
                  className="text-xl transition-colors duration-300 group-hover:text-transparent bg-clip-text"
                  style={
                    {
                      backgroundImage: `linear-gradient(90deg, ${color}, ${color})`,
                      backgroundSize: "0 100%",
                      backgroundRepeat: "no-repeat",
                      transition: "color 0.3s ease, background-size 0.3s ease",
                      backgroundSize: "0% 100%",
                      "--hover-bg-size": "100% 100%",
                    } as React.CSSProperties
                  }
                >
                  <span
                    className="group-hover:bg-gradient-to-r group-hover:from-current group-hover:to-current group-hover:bg-clip-text group-hover:text-transparent"
                    style={{ color }}
                  >
                    {team.name}
                  </span>
                </CardTitle>
                <IconComponent className="h-8 w-8 p-1 rounded-full transition-colors duration-300" style={{ color }} />
              </div>
            </CardHeader>
            <CardContent className="pt-4">
              <p className="text-muted-foreground transition-colors duration-300 group-hover:text-muted-foreground/80">
                {team.description}
              </p>
            </CardContent>
            <CardFooter className="flex flex-wrap gap-2 pt-0">
              {links.map((link, i) => (
                <Button
                  key={i}
                  variant="outline"
                  size="sm"
                  asChild
                  className="text-xs transition-all duration-300 group-hover:border-current"
                  style={
                    {
                      "--hover-color": color,
                    } as React.CSSProperties
                  }
                >
                  <a href={link.url} className="group-hover:text-[var(--hover-color)] transition-colors duration-300">
                    {link.label}
                  </a>
                </Button>
              ))}
            </CardFooter>
          </Card>
        )
      })}
    </div>
  )
}
