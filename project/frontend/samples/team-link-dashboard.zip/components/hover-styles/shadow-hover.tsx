import type React from "react"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { getTeamLinks, chartColors } from "@/lib/utils"
import type { TeamPart } from "@/lib/team-data"
import type { LucideIcon } from "lucide-react"
import * as LucideIcons from "lucide-react"

interface ShadowHoverProps {
  teams: TeamPart[]
}

export default function ShadowHover({ teams }: ShadowHoverProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {teams.map((team, index) => {
        const IconComponent =
          (LucideIcons as Record<string, LucideIcon>)[team.icon.charAt(0).toUpperCase() + team.icon.slice(1)] ||
          LucideIcons.Briefcase

        const color = chartColors.vibrant[index % chartColors.vibrant.length]
        const links = getTeamLinks(team)

        // Convert color to RGB for shadow
        const colorRgb = color.replace("hsl", "hsla").replace(")", ", 0.5)")

        return (
          <Card
            key={team.name}
            className="overflow-hidden transition-all duration-500 group hover:translate-y-[-5px]"
            style={{
              boxShadow: "0 4px 6px rgba(0, 0, 0, 0.1)",
              transition: "all 0.5s cubic-bezier(0.175, 0.885, 0.32, 1.275)",
            }}
          >
            {/* Custom shadow style that changes on hover */}
            <div
              className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-all duration-500 rounded-lg"
              style={{
                boxShadow: `0 10px 30px -5px ${colorRgb}, 0 0 10px ${colorRgb}`,
                transform: "translateY(5px)",
                zIndex: -1,
              }}
            />

            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-xl group-hover:text-foreground transition-colors duration-500">
                  {team.name}
                </CardTitle>
                <div
                  className="p-2 rounded-full transition-all duration-500"
                  style={{
                    backgroundColor: `${color}20`,
                    transform: "translateZ(0)",
                  }}
                >
                  <IconComponent
                    className="h-6 w-6 transition-all duration-500 group-hover:scale-110"
                    style={{ color }}
                  />
                </div>
              </div>
            </CardHeader>
            <CardContent className="pt-4">
              <p className="text-muted-foreground transition-colors duration-500">{team.description}</p>
            </CardContent>
            <CardFooter className="flex flex-wrap gap-2 pt-0">
              {links.map((link, i) => (
                <Button
                  key={i}
                  variant="outline"
                  size="sm"
                  asChild
                  className="text-xs transition-all duration-500 group-hover:shadow-md"
                  style={
                    {
                      "--hover-color": color,
                      transform: "translateZ(0)",
                    } as React.CSSProperties
                  }
                >
                  <a href={link.url} className="group-hover:text-[var(--hover-color)] transition-colors duration-500">
                    {link.label}
                  </a>
                </Button>
              ))}
            </CardFooter>
          </Card>
        )
      })}
    </div>
  )
}
