import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { getTeamLinks, chartColors } from "@/lib/utils"
import type { TeamPart } from "@/lib/team-data"
import type { LucideIcon } from "lucide-react"
import * as LucideIcons from "lucide-react"

interface BackgroundHoverProps {
  teams: TeamPart[]
}

export default function BackgroundHover({ teams }: BackgroundHoverProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {teams.map((team, index) => {
        const IconComponent =
          (LucideIcons as Record<string, LucideIcon>)[team.icon.charAt(0).toUpperCase() + team.icon.slice(1)] ||
          LucideIcons.Briefcase

        const color = chartColors.primary[index % chartColors.primary.length]
        const links = getTeamLinks(team)

        return (
          <Card key={team.name} className="overflow-hidden transition-all duration-300 group hover:shadow-lg">
            <CardHeader
              className="pb-2 transition-colors duration-300 group-hover:text-white"
              style={{
                backgroundColor: `${color}10`,
                transition: "background-color 0.3s ease",
              }}
              data-color={color}
            >
              <div className="flex items-center justify-between">
                <CardTitle className="text-xl">{team.name}</CardTitle>
                <IconComponent className="h-8 w-8 p-1 rounded-full transition-colors duration-300" style={{ color }} />
              </div>
            </CardHeader>
            <CardContent className="pt-4 transition-colors duration-300 group-hover:text-white">
              <p className="text-muted-foreground group-hover:text-white/80 transition-colors duration-300">
                {team.description}
              </p>
            </CardContent>
            <CardFooter className="flex flex-wrap gap-2 pt-0 transition-colors duration-300 group-hover:text-white">
              {links.map((link, i) => (
                <Button
                  key={i}
                  variant="outline"
                  size="sm"
                  asChild
                  className="text-xs transition-colors duration-300 group-hover:border-white group-hover:text-white"
                >
                  <a href={link.url}>{link.label}</a>
                </Button>
              ))}
            </CardFooter>

            {/* Hover overlay with background color */}
            <div
              className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300 -z-10"
              style={{ backgroundColor: color }}
            />
          </Card>
        )
      })}
    </div>
  )
}
