import type React from "react"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { getTeamLinks, chartColors } from "@/lib/utils"
import type { TeamPart } from "@/lib/team-data"
import type { LucideIcon } from "lucide-react"
import * as LucideIcons from "lucide-react"

interface RotateHoverProps {
  teams: TeamPart[]
}

export default function RotateHover({ teams }: RotateHoverProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {teams.map((team, index) => {
        const IconComponent =
          (LucideIcons as Record<string, LucideIcon>)[team.icon.charAt(0).toUpperCase() + team.icon.slice(1)] ||
          LucideIcons.Briefcase

        const color = chartColors.vibrant[index % chartColors.vibrant.length]
        const links = getTeamLinks(team)

        return (
          <div key={team.name} className="group perspective-1000">
            <Card
              className="overflow-hidden transition-all duration-500 transform-gpu group-hover:rotate-y-10 group-hover:shadow-xl relative"
              style={
                {
                  transformStyle: "preserve-3d",
                } as React.CSSProperties
              }
            >
              {/* 3D effect elements */}
              <div
                className="absolute inset-0 bg-gradient-to-tr opacity-0 group-hover:opacity-10 transition-opacity duration-500"
                style={{
                  background: `linear-gradient(135deg, ${color} 0%, transparent 50%)`,
                  transform: "translateZ(-10px)",
                  borderRadius: "inherit",
                }}
              />

              <CardHeader className="pb-2 relative" style={{ transform: "translateZ(10px)" }}>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-xl">{team.name}</CardTitle>
                  <div
                    className="p-2 rounded-full transition-all duration-500 transform-gpu group-hover:rotate-[360deg]"
                    style={{ backgroundColor: `${color}20` }}
                  >
                    <IconComponent className="h-6 w-6 transition-colors duration-500" style={{ color }} />
                  </div>
                </div>
              </CardHeader>
              <CardContent className="pt-4 relative" style={{ transform: "translateZ(5px)" }}>
                <p className="text-muted-foreground">{team.description}</p>
              </CardContent>
              <CardFooter className="flex flex-wrap gap-2 pt-0 relative" style={{ transform: "translateZ(15px)" }}>
                {links.map((link, i) => (
                  <Button
                    key={i}
                    variant="outline"
                    size="sm"
                    asChild
                    className="text-xs transition-all duration-500 group-hover:shadow-md"
                    style={
                      {
                        "--hover-color": color,
                      } as React.CSSProperties
                    }
                  >
                    <a href={link.url} className="group-hover:text-[var(--hover-color)] transition-colors duration-500">
                      {link.label}
                    </a>
                  </Button>
                ))}
              </CardFooter>

              {/* Edge highlight effect */}
              <div
                className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none"
                style={{
                  boxShadow: `inset 0 0 0 1px ${color}40`,
                  borderRadius: "inherit",
                  transform: "translateZ(20px)",
                }}
              />
            </Card>
          </div>
        )
      })}
    </div>
  )
}
