import type React from "react"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { getTeamLinks, chartColors } from "@/lib/utils"
import type { TeamPart } from "@/lib/team-data"
import type { LucideIcon } from "lucide-react"
import * as LucideIcons from "lucide-react"

interface ScaleHoverProps {
  teams: TeamPart[]
}

export default function ScaleHover({ teams }: ScaleHoverProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {teams.map((team, index) => {
        const IconComponent =
          (LucideIcons as Record<string, LucideIcon>)[team.icon.charAt(0).toUpperCase() + team.icon.slice(1)] ||
          LucideIcons.Briefcase

        const color = chartColors.primary[index % chartColors.primary.length]
        const links = getTeamLinks(team)

        return (
          <div key={team.name} className="relative group perspective-1000">
            <Card className="overflow-hidden transition-all duration-300 transform-gpu group-hover:scale-105 group-hover:shadow-xl">
              <CardHeader className="pb-2 relative">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-xl">{team.name}</CardTitle>
                  <div className="relative">
                    {/* Icon background that scales on hover */}
                    <div
                      className="absolute inset-0 rounded-full transition-transform duration-300 transform-gpu group-hover:scale-[1.5] opacity-0 group-hover:opacity-100"
                      style={{ backgroundColor: color }}
                    />
                    <IconComponent
                      className="h-8 w-8 p-1 rounded-full relative z-10 transition-colors duration-300 group-hover:text-white"
                      style={{ color }}
                    />
                  </div>
                </div>
              </CardHeader>
              <CardContent className="pt-4">
                <p className="text-muted-foreground">{team.description}</p>
              </CardContent>
              <CardFooter className="flex flex-wrap gap-2 pt-0">
                {links.map((link, i) => (
                  <Button
                    key={i}
                    variant="outline"
                    size="sm"
                    asChild
                    className="text-xs transition-all duration-300 group-hover:border-current"
                    style={
                      {
                        "--hover-color": color,
                      } as React.CSSProperties
                    }
                  >
                    <a href={link.url} className="group-hover:text-[var(--hover-color)] transition-colors duration-300">
                      {link.label}
                    </a>
                  </Button>
                ))}
              </CardFooter>
            </Card>

            {/* Decorative element that appears on hover */}
            <div
              className="absolute -bottom-2 -right-2 w-12 h-12 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300 transform-gpu group-hover:scale-100 scale-50"
              style={{ backgroundColor: `${color}40` }}
            />
            <div
              className="absolute -top-2 -left-2 w-8 h-8 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300 transform-gpu group-hover:scale-100 scale-50"
              style={{ backgroundColor: `${color}20` }}
            />
          </div>
        )
      })}
    </div>
  )
}
