import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { getTeamLinks, chartColors } from "@/lib/utils"
import type { TeamPart } from "@/lib/team-data"
import type { LucideIcon } from "lucide-react"
import * as LucideIcons from "lucide-react"

interface GradientHoverProps {
  teams: TeamPart[]
}

export default function GradientHover({ teams }: GradientHoverProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {teams.map((team, index) => {
        const IconComponent =
          (LucideIcons as Record<string, LucideIcon>)[team.icon.charAt(0).toUpperCase() + team.icon.slice(1)] ||
          LucideIcons.Briefcase

        const gradientIndex = index % chartColors.gradient.length
        const gradient = chartColors.gradient[gradientIndex]
        const color = chartColors.vibrant[index % chartColors.vibrant.length]
        const links = getTeamLinks(team)

        return (
          <Card key={team.name} className="overflow-hidden transition-all duration-500 group relative border-none">
            {/* Gradient background that appears on hover */}
            <div
              className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 -z-10"
              style={{ background: gradient }}
            />

            {/* Card shadow for depth */}
            <div className="absolute inset-0 shadow-md rounded-lg z-0"></div>

            <CardHeader className="pb-2 relative z-10 transition-colors duration-500 group-hover:text-white">
              <div className="flex items-center justify-between">
                <CardTitle className="text-xl">{team.name}</CardTitle>
                <div className="p-2 rounded-full bg-white/10 backdrop-blur-sm transition-all duration-500 group-hover:bg-white/20">
                  <IconComponent className="h-6 w-6 transition-colors duration-500 text-muted-foreground group-hover:text-white" />
                </div>
              </div>
            </CardHeader>
            <CardContent className="pt-4 relative z-10 transition-colors duration-500 group-hover:text-white">
              <p className="text-muted-foreground transition-colors duration-500 group-hover:text-white/80">
                {team.description}
              </p>
            </CardContent>
            <CardFooter className="flex flex-wrap gap-2 pt-0 relative z-10">
              {links.map((link, i) => (
                <Button
                  key={i}
                  variant="outline"
                  size="sm"
                  asChild
                  className="text-xs transition-all duration-500 bg-transparent border-current group-hover:border-white/50 group-hover:text-white group-hover:bg-white/10"
                >
                  <a href={link.url}>{link.label}</a>
                </Button>
              ))}
            </CardFooter>
          </Card>
        )
      })}
    </div>
  )
}
