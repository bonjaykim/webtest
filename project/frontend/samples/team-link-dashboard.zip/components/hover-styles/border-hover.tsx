import type React from "react"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { getTeamLinks, chartColors } from "@/lib/utils"
import type { TeamPart } from "@/lib/team-data"
import type { LucideIcon } from "lucide-react"
import * as LucideIcons from "lucide-react"

interface BorderHoverProps {
  teams: TeamPart[]
}

export default function BorderHover({ teams }: BorderHoverProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {teams.map((team, index) => {
        const IconComponent =
          (LucideIcons as Record<string, LucideIcon>)[team.icon.charAt(0).toUpperCase() + team.icon.slice(1)] ||
          LucideIcons.Briefcase

        const color = chartColors.secondary[index % chartColors.secondary.length]
        const links = getTeamLinks(team)

        return (
          <Card
            key={team.name}
            className="overflow-hidden transition-all duration-300 group relative border-2 hover:border-transparent"
          >
            {/* Border overlay that appears on hover */}
            <div
              className="absolute inset-0 rounded-[calc(var(--radius)-1px)] opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none"
              style={{
                background: `linear-gradient(to right, ${color}, ${color}) border-box`,
                border: `2px solid transparent`,
                WebkitMask: "linear-gradient(#fff 0 0) padding-box, linear-gradient(#fff 0 0)",
                WebkitMaskComposite: "xor",
                maskComposite: "exclude",
              }}
            />

            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-xl">{team.name}</CardTitle>
                <div
                  className="p-2 rounded-full transition-colors duration-300 group-hover:bg-opacity-20"
                  style={{
                    backgroundColor: `${color}10`,
                    transition: "background-color 0.3s ease",
                  }}
                >
                  <IconComponent className="h-6 w-6 transition-colors duration-300" style={{ color }} />
                </div>
              </div>
            </CardHeader>
            <CardContent className="pt-4">
              <p className="text-muted-foreground">{team.description}</p>
            </CardContent>
            <CardFooter className="flex flex-wrap gap-2 pt-0">
              {links.map((link, i) => (
                <Button
                  key={i}
                  variant="outline"
                  size="sm"
                  asChild
                  className="text-xs transition-all duration-300 group-hover:border-current"
                  style={
                    {
                      color: "inherit",
                      borderColor: "currentColor",
                      "--hover-color": color,
                    } as React.CSSProperties
                  }
                >
                  <a href={link.url} className="group-hover:text-[var(--hover-color)] transition-colors duration-300">
                    {link.label}
                  </a>
                </Button>
              ))}
            </CardFooter>
          </Card>
        )
      })}
    </div>
  )
}
