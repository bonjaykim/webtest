import type React from "react"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { getTeamLinks, chartColors } from "@/lib/utils"
import type { TeamPart } from "@/lib/team-data"
import type { LucideIcon } from "lucide-react"
import * as LucideIcons from "lucide-react"

interface RotateGlowIconComboProps {
  teams: TeamPart[]
  colorTheme?: string
}

export default function RotateGlowIconCombo({ teams, colorTheme = "sapphire" }: RotateGlowIconComboProps) {
  // 선택된 테마의 첫 번째 색상을 모든 카드에 적용
  const themeColors = chartColors[colorTheme as keyof typeof chartColors] || chartColors.sapphire
  const color = themeColors[0] // 모든 카드에 동일한 색상 적용

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {teams.map((team) => {
        const IconComponent =
          (LucideIcons as Record<string, LucideIcon>)[team.icon.charAt(0).toUpperCase() + team.icon.slice(1)] ||
          LucideIcons.Briefcase

        const links = getTeamLinks(team)

        return (
          <div key={team.name} className="group perspective-1000">
            <Card
              className="h-full overflow-hidden transition-all duration-500 transform-gpu group-hover:rotate-y-10 group-hover:shadow-xl relative border-2"
              style={
                {
                  transformStyle: "preserve-3d",
                  // 카드 가시성 개선
                  backgroundColor: `${color}05`, // 매우 연한 배경색
                  borderColor: `${color}30`, // 연한 테두리 색상
                  boxShadow: "0 2px 10px rgba(0, 0, 0, 0.05)", // 약간의 그림자
                } as React.CSSProperties
              }
            >
              {/* 3D effect elements */}
              <div
                className="absolute inset-0 bg-gradient-to-tr opacity-0 group-hover:opacity-10 transition-opacity duration-500"
                style={{
                  background: `linear-gradient(135deg, ${color} 0%, transparent 50%)`,
                  transform: "translateZ(-10px)",
                  borderRadius: "inherit",
                }}
              />

              {/* Border effect on hover */}
              <div
                className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none rounded-lg"
                style={{
                  boxShadow: `inset 0 0 0 2px ${color}`,
                }}
              />

              <CardHeader className="pb-2 relative" style={{ transform: "translateZ(10px)" }}>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-xl group-hover:text-foreground transition-colors duration-500">
                    {team.name}
                  </CardTitle>
                  <div className="relative">
                    {/* 아이콘 배경을 항상 표시하되, hover 시 불투명도 증가 */}
                    <div
                      className="absolute inset-0 rounded-full transition-all duration-500 transform-gpu group-hover:rotate-[360deg]"
                      style={{
                        backgroundColor: color,
                        opacity: 0.8, // 기본 상태에서도 배경 표시
                      }}
                    />
                    {/* 아이콘을 항상 흰색으로 표시 */}
                    <IconComponent className="h-8 w-8 p-1 rounded-full relative z-10 transition-all duration-500 text-white group-hover:rotate-[360deg]" />
                  </div>
                </div>
              </CardHeader>
              <CardContent className="pt-4 pb-2 relative" style={{ transform: "translateZ(5px)" }}>
                {/* 설명 텍스트 - 모두 표시되도록 수정 */}
                <p className="text-muted-foreground" style={{ lineHeight: "1.5rem" }}>
                  {team.description}
                </p>
              </CardContent>
              <CardFooter className="flex flex-wrap gap-2 pt-2 relative" style={{ transform: "translateZ(15px)" }}>
                {links.map((link, i) => (
                  <Button
                    key={i}
                    variant="outline"
                    size="sm"
                    asChild
                    className="text-xs transition-all duration-500 group-hover:shadow-md"
                    style={
                      {
                        "--hover-color": color,
                      } as React.CSSProperties
                    }
                  >
                    <a href={link.url} className="group-hover:text-[var(--hover-color)] transition-colors duration-500">
                      {link.label}
                    </a>
                  </Button>
                ))}
              </CardFooter>

              {/* Large decorative icon in the background */}
              <div
                className="absolute -bottom-12 -right-12 opacity-0 group-hover:opacity-10 transition-opacity duration-500"
                style={{ transform: "translateZ(-5px)" }}
              >
                <IconComponent className="h-40 w-40" style={{ color }} />
              </div>
            </Card>
          </div>
        )
      })}
    </div>
  )
}
