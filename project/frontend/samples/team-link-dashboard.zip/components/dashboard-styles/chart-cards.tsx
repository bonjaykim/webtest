import type { TeamPart } from "@/lib/team-data"
import { getTeamLinks, chartColors, getRandomData } from "@/lib/utils"
import type { LucideIcon } from "lucide-react"
import * as LucideIcons from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { AreaChart, Area, BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, ResponsiveContainer } from "recharts"

interface ChartCardsProps {
  teams: TeamPart[]
}

export default function ChartCards({ teams }: ChartCardsProps) {
  const chartTypes = ["area", "bar", "line", "pie", "area", "bar"]

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {teams.map((team, index) => {
        const IconComponent =
          (LucideIcons as Record<string, LucideIcon>)[team.icon.charAt(0).toUpperCase() + team.icon.slice(1)] ||
          LucideIcons.Briefcase

        const color = chartColors.primary[index % chartColors.primary.length]
        const links = getTeamLinks(team)
        const chartType = chartTypes[index % chartTypes.length]

        // 차트 데이터 생성
        const data = getRandomData(6).map((value, i) => ({
          name: `${String.fromCharCode(65 + i)}`,
          value,
        }))

        return (
          <Card key={team.name} className="overflow-hidden">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-xl flex items-center gap-2">
                  <IconComponent className="h-5 w-5" style={{ color }} />
                  {team.name}
                </CardTitle>
              </div>
            </CardHeader>
            <CardContent className="p-4">
              <div className="h-32 mb-4">
                <ResponsiveContainer width="100%" height="100%">
                  {renderChart(chartType, data, color)}
                </ResponsiveContainer>
              </div>
              <p className="text-sm text-muted-foreground">{team.description}</p>
            </CardContent>
            <CardFooter className="flex flex-wrap gap-2 pt-0">
              {links.map((link, i) => (
                <Button key={i} variant="outline" size="sm" asChild className="text-xs">
                  <a href={link.url}>{link.label}</a>
                </Button>
              ))}
            </CardFooter>
          </Card>
        )
      })}
    </div>
  )
}

function renderChart(type: string, data: any[], color: string) {
  switch (type) {
    case "area":
      return (
        <AreaChart data={data}>
          <defs>
            <linearGradient id={`color${color}`} x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor={color} stopOpacity={0.8} />
              <stop offset="95%" stopColor={color} stopOpacity={0.1} />
            </linearGradient>
          </defs>
          <Area type="monotone" dataKey="value" stroke={color} fillOpacity={1} fill={`url(#color${color})`} />
        </AreaChart>
      )
    case "bar":
      return (
        <BarChart data={data}>
          <Bar dataKey="value" fill={color} />
        </BarChart>
      )
    case "line":
      return (
        <LineChart data={data}>
          <Line type="monotone" dataKey="value" stroke={color} strokeWidth={2} />
        </LineChart>
      )
    case "pie":
      return (
        <PieChart>
          <Pie data={data} cx="50%" cy="50%" innerRadius={30} outerRadius={50} paddingAngle={5} dataKey="value">
            {data.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={chartColors.pastel[index % chartColors.pastel.length]} />
            ))}
          </Pie>
        </PieChart>
      )
    default:
      return (
        <AreaChart data={data}>
          <Area type="monotone" dataKey="value" stroke={color} fill={color} fillOpacity={0.3} />
        </AreaChart>
      )
  }
}
