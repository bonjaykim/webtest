import type { TeamPart } from "@/lib/team-data"
import { getTeamLinks, chartColors } from "@/lib/utils"
import type { LucideIcon } from "lucide-react"
import * as LucideIcons from "lucide-react"
import { Button } from "@/components/ui/button"
import { ChevronRight } from "lucide-react"

interface ListStyleProps {
  teams: TeamPart[]
}

export default function ListStyle({ teams }: ListStyleProps) {
  return (
    <div className="space-y-4">
      {teams.map((team, index) => {
        const IconComponent =
          (LucideIcons as Record<string, LucideIcon>)[team.icon.charAt(0).toUpperCase() + team.icon.slice(1)] ||
          LucideIcons.Briefcase

        const color = chartColors.secondary[index % chartColors.secondary.length]
        const links = getTeamLinks(team)

        return (
          <div
            key={team.name}
            className="flex flex-col md:flex-row md:items-center justify-between p-4 rounded-lg border gap-4 hover:bg-muted/50 transition-colors"
          >
            <div className="flex items-center gap-4">
              <div className="p-3 rounded-full" style={{ backgroundColor: `${color}20` }}>
                <IconComponent className="h-6 w-6" style={{ color }} />
              </div>
              <div>
                <h3 className="font-medium text-lg">{team.name}</h3>
                <p className="text-muted-foreground text-sm">{team.description}</p>
              </div>
            </div>
            <div className="flex flex-wrap gap-2 mt-2 md:mt-0">
              {links.map((link, i) => (
                <Button key={i} variant="ghost" size="sm" asChild className="text-xs">
                  <a href={link.url} className="flex items-center">
                    {link.label}
                    <ChevronRight className="ml-1 h-3 w-3" />
                  </a>
                </Button>
              ))}
            </div>
          </div>
        )
      })}
    </div>
  )
}
