import type { TeamPart } from "@/lib/team-data"
import { getTeamLinks, chartColors } from "@/lib/utils"
import type { LucideIcon } from "lucide-react"
import * as LucideIcons from "lucide-react"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

interface TabsStyleProps {
  teams: TeamPart[]
}

export default function TabsStyle({ teams }: TabsStyleProps) {
  return (
    <Tabs defaultValue={teams[0].name.replace(/\s+/g, "-").toLowerCase()}>
      <TabsList className="grid grid-cols-3 md:grid-cols-6 h-auto">
        {teams.map((team, index) => {
          const IconComponent =
            (LucideIcons as Record<string, LucideIcon>)[team.icon.charAt(0).toUpperCase() + team.icon.slice(1)] ||
            LucideIcons.Briefcase

          const color = chartColors.primary[index % chartColors.primary.length]

          return (
            <TabsTrigger
              key={team.name}
              value={team.name.replace(/\s+/g, "-").toLowerCase()}
              className="flex items-center gap-2 py-2"
            >
              <IconComponent className="h-4 w-4" />
              <span className="hidden md:inline">{team.name}</span>
            </TabsTrigger>
          )
        })}
      </TabsList>

      {teams.map((team, index) => {
        const IconComponent =
          (LucideIcons as Record<string, LucideIcon>)[team.icon.charAt(0).toUpperCase() + team.icon.slice(1)] ||
          LucideIcons.Briefcase

        const color = chartColors.primary[index % chartColors.primary.length]
        const links = getTeamLinks(team)

        return (
          <TabsContent key={team.name} value={team.name.replace(/\s+/g, "-").toLowerCase()}>
            <Card>
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className="p-3 rounded-full" style={{ backgroundColor: `${color}20` }}>
                    <IconComponent className="h-6 w-6" style={{ color }} />
                  </div>
                  <div>
                    <CardTitle>{team.name}</CardTitle>
                    <CardDescription>{team.description}</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="col-span-1 md:col-span-2">
                    <h4 className="font-medium mb-2">팀 소개</h4>
                    <p className="text-muted-foreground">
                      {team.name}은(는) {team.description} 이 팀은 회사의 핵심 부서 중 하나로, 다양한 프로젝트와
                      이니셔티브를 통해 회사의 성장에 기여하고 있습니다.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-medium mb-2">주요 링크</h4>
                    <ul className="space-y-1">
                      {links.map((link, i) => (
                        <li key={i}>
                          <a href={link.url} className="text-sm hover:underline" style={{ color }}>
                            {link.label}
                          </a>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="flex justify-end gap-2">
                <Button variant="outline" asChild>
                  <a href={team.link}>자세히 보기</a>
                </Button>
                <Button style={{ backgroundColor: color }} asChild>
                  <a href={`/contact/${team.name.toLowerCase()}`}>연락하기</a>
                </Button>
              </CardFooter>
            </Card>
          </TabsContent>
        )
      })}
    </Tabs>
  )
}
