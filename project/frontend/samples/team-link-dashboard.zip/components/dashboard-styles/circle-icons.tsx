import type { TeamPart } from "@/lib/team-data"
import { getTeamLinks, chartColors } from "@/lib/utils"
import type { LucideIcon } from "lucide-react"
import * as LucideIcons from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"

interface CircleIconsProps {
  teams: TeamPart[]
}

export default function CircleIcons({ teams }: CircleIconsProps) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
      {teams.map((team, index) => {
        const IconComponent =
          (LucideIcons as Record<string, LucideIcon>)[team.icon.charAt(0).toUpperCase() + team.icon.slice(1)] ||
          LucideIcons.Briefcase

        const color = chartColors.vibrant[index % chartColors.vibrant.length]
        const links = getTeamLinks(team)

        return (
          <Card key={team.name} className="relative pt-10 border-none shadow-md">
            <div className="absolute -top-8 left-1/2 transform -translate-x-1/2">
              <div
                className="rounded-full p-4 w-16 h-16 flex items-center justify-center"
                style={{ backgroundColor: color }}
              >
                <IconComponent className="h-8 w-8 text-white" />
              </div>
            </div>
            <CardContent className="pt-6 text-center">
              <h3 className="font-bold text-xl mb-2">{team.name}</h3>
              <p className="text-muted-foreground mb-6">{team.description}</p>
              <div className="flex flex-wrap justify-center gap-2">
                {links.map((link, i) => (
                  <Button
                    key={i}
                    variant="outline"
                    size="sm"
                    asChild
                    className="text-xs rounded-full"
                    style={{ borderColor: color, color }}
                  >
                    <a href={link.url}>{link.label}</a>
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>
        )
      })}
    </div>
  )
}
