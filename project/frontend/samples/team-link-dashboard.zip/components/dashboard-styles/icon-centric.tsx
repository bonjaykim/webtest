import type { TeamPart } from "@/lib/team-data"
import { getTeamLinks, chartColors } from "@/lib/utils"
import type { LucideIcon } from "lucide-react"
import * as LucideIcons from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"

interface IconCentricProps {
  teams: TeamPart[]
}

export default function IconCentric({ teams }: IconCentricProps) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
      {teams.map((team, index) => {
        const IconComponent =
          (LucideIcons as Record<string, LucideIcon>)[team.icon.charAt(0).toUpperCase() + team.icon.slice(1)] ||
          LucideIcons.Briefcase

        const color = chartColors.vibrant[index % chartColors.vibrant.length]
        const links = getTeamLinks(team)

        return (
          <Card key={team.name} className="overflow-hidden border-none shadow-lg">
            <div className="h-24 flex items-center justify-center" style={{ backgroundColor: color }}>
              <IconComponent className="h-12 w-12 text-white" />
            </div>
            <CardContent className="p-6">
              <h3 className="font-bold text-xl mb-2">{team.name}</h3>
              <p className="text-muted-foreground mb-4">{team.description}</p>
              <div className="flex flex-wrap gap-2">
                {links.map((link, i) => (
                  <Button
                    key={i}
                    variant="outline"
                    size="sm"
                    asChild
                    className="text-xs"
                    style={{ borderColor: color, color }}
                  >
                    <a href={link.url}>{link.label}</a>
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>
        )
      })}
    </div>
  )
}
