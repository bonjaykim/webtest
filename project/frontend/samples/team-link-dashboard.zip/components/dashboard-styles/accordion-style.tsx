import type { TeamPart } from "@/lib/team-data"
import { getTeamLinks, chartColors } from "@/lib/utils"
import type { LucideIcon } from "lucide-react"
import * as LucideIcons from "lucide-react"
import { Button } from "@/components/ui/button"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"

interface AccordionStyleProps {
  teams: TeamPart[]
}

export default function AccordionStyle({ teams }: AccordionStyleProps) {
  return (
    <Accordion type="single" collapsible className="w-full">
      {teams.map((team, index) => {
        const IconComponent =
          (LucideIcons as Record<string, LucideIcon>)[team.icon.charAt(0).toUpperCase() + team.icon.slice(1)] ||
          LucideIcons.Briefcase

        const color = chartColors.pastel[index % chartColors.pastel.length]
        const links = getTeamLinks(team)

        return (
          <AccordionItem key={team.name} value={team.name}>
            <AccordionTrigger className="hover:no-underline">
              <div className="flex items-center gap-3 text-left">
                <div className="p-2 rounded-md" style={{ backgroundColor: `${color}40` }}>
                  <IconComponent className="h-5 w-5" style={{ color }} />
                </div>
                <div>
                  <h3 className="font-medium">{team.name}</h3>
                  <p className="text-sm text-muted-foreground">{team.description}</p>
                </div>
              </div>
            </AccordionTrigger>
            <AccordionContent>
              <div className="pt-4 pb-2 px-2">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                  <div>
                    <h4 className="text-sm font-medium mb-2">팀 소개</h4>
                    <p className="text-sm text-muted-foreground">
                      {team.name}은(는) {team.description} 이 팀은 회사의 핵심 부서 중 하나로, 다양한 프로젝트와
                      이니셔티브를 통해 회사의 성장에 기여하고 있습니다.
                    </p>
                  </div>
                  <div>
                    <h4 className="text-sm font-medium mb-2">주요 링크</h4>
                    <div className="flex flex-wrap gap-2">
                      {links.map((link, i) => (
                        <Button
                          key={i}
                          variant="outline"
                          size="sm"
                          asChild
                          className="text-xs"
                          style={{ borderColor: color, color }}
                        >
                          <a href={link.url}>{link.label}</a>
                        </Button>
                      ))}
                    </div>
                  </div>
                </div>
                <div className="flex justify-end">
                  <Button style={{ backgroundColor: color }} className="text-white" asChild>
                    <a href={`/contact/${team.name.toLowerCase()}`}>연락하기</a>
                  </Button>
                </div>
              </div>
            </AccordionContent>
          </AccordionItem>
        )
      })}
    </Accordion>
  )
}
