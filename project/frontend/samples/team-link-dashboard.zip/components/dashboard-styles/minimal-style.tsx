import type { TeamPart } from "@/lib/team-data"
import { getTeamLinks, chartColors } from "@/lib/utils"
import type { LucideIcon } from "lucide-react"
import * as LucideIcons from "lucide-react"
import { ArrowRight } from "lucide-react"

interface MinimalStyleProps {
  teams: TeamPart[]
}

export default function MinimalStyle({ teams }: MinimalStyleProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {teams.map((team, index) => {
        const IconComponent =
          (LucideIcons as Record<string, LucideIcon>)[team.icon.charAt(0).toUpperCase() + team.icon.slice(1)] ||
          LucideIcons.Briefcase

        const color = chartColors.monochrome[index % chartColors.monochrome.length]
        const links = getTeamLinks(team)

        return (
          <div
            key={team.name}
            className="group p-6 border border-border/50 rounded-lg hover:border-foreground/20 transition-all"
          >
            <div className="flex items-center gap-3 mb-4">
              <IconComponent className="h-5 w-5 text-muted-foreground group-hover:text-foreground transition-colors" />
              <h3 className="font-medium text-lg">{team.name}</h3>
            </div>
            <p className="text-muted-foreground mb-6 text-sm">{team.description}</p>
            <div className="space-y-2">
              {links.map((link, i) => (
                <a key={i} href={link.url} className="flex items-center justify-between text-sm hover:underline">
                  <span>{link.label}</span>
                  <ArrowRight className="h-3 w-3 opacity-0 -translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition-all" />
                </a>
              ))}
            </div>
          </div>
        )
      })}
    </div>
  )
}
