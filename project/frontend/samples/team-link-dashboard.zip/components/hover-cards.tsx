"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import BackgroundHover from "./hover-styles/background-hover"
import BorderHover from "./hover-styles/border-hover"
import GradientHover from "./hover-styles/gradient-hover"
import ScaleHover from "./hover-styles/scale-hover"
import ShadowHover from "./hover-styles/shadow-hover"
import IconHover from "./hover-styles/icon-hover"
import TextHover from "./hover-styles/text-hover"
import RotateHover from "./hover-styles/rotate-hover"
import { teamData } from "@/lib/team-data"

export default function HoverCards() {
  const [activeTab, setActiveTab] = useState("background")

  return (
    <div className="space-y-6">
      <Tabs defaultValue="background" onValueChange={setActiveTab} className="w-full">
        <div className="flex justify-center mb-6">
          <TabsList className="grid grid-cols-4 md:grid-cols-8">
            <TabsTrigger value="background">배경</TabsTrigger>
            <TabsTrigger value="border">테두리</TabsTrigger>
            <TabsTrigger value="gradient">그라데이션</TabsTrigger>
            <TabsTrigger value="scale">확대/축소</TabsTrigger>
            <TabsTrigger value="shadow">그림자</TabsTrigger>
            <TabsTrigger value="icon">아이콘</TabsTrigger>
            <TabsTrigger value="text">텍스트</TabsTrigger>
            <TabsTrigger value="rotate">회전</TabsTrigger>
          </TabsList>
        </div>

        <TabsContent value="background">
          <BackgroundHover teams={teamData} />
        </TabsContent>

        <TabsContent value="border">
          <BorderHover teams={teamData} />
        </TabsContent>

        <TabsContent value="gradient">
          <GradientHover teams={teamData} />
        </TabsContent>

        <TabsContent value="scale">
          <ScaleHover teams={teamData} />
        </TabsContent>

        <TabsContent value="shadow">
          <ShadowHover teams={teamData} />
        </TabsContent>

        <TabsContent value="icon">
          <IconHover teams={teamData} />
        </TabsContent>

        <TabsContent value="text">
          <TextHover teams={teamData} />
        </TabsContent>

        <TabsContent value="rotate">
          <RotateHover teams={teamData} />
        </TabsContent>
      </Tabs>
    </div>
  )
}
