import type React from "react"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { getTeamLinks, chartColors } from "@/lib/utils"
import type { TeamPart } from "@/lib/team-data"
import type { LucideIcon } from "lucide-react"
import * as LucideIcons from "lucide-react"

interface GlowIconComboProps {
  teams: TeamPart[]
}

export default function GlowIconCombo({ teams }: GlowIconComboProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {teams.map((team, index) => {
        const IconComponent =
          (LucideIcons as Record<string, LucideIcon>)[team.icon.charAt(0).toUpperCase() + team.icon.slice(1)] ||
          LucideIcons.Briefcase

        const color = chartColors.sapphire[index % chartColors.sapphire.length]
        const links = getTeamLinks(team)

        // Convert color to RGB for glow
        const colorRgb = color.replace("hsl", "hsla").replace(")", ", 0.6)")

        return (
          <div key={team.name} className="group perspective-1000">
            <Card
              className="overflow-hidden transition-all duration-500 transform-gpu group-hover:rotate-y-5 relative border-none"
              style={
                {
                  transformStyle: "preserve-3d",
                  boxShadow: "0 4px 6px rgba(0, 0, 0, 0.1)",
                } as React.CSSProperties
              }
            >
              {/* Glow effect */}
              <div
                className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-all duration-500 rounded-lg"
                style={{
                  boxShadow: `0 0 20px ${colorRgb}, 0 0 30px ${colorRgb}`,
                  transform: "translateZ(-10px)",
                }}
              />

              <CardHeader className="pb-2 relative" style={{ transform: "translateZ(10px)" }}>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-xl">{team.name}</CardTitle>
                  <div className="relative">
                    {/* Glowing icon container */}
                    <div
                      className="absolute inset-0 rounded-full opacity-0 group-hover:opacity-100 transition-all duration-500 animate-pulse-slow"
                      style={{
                        backgroundColor: color,
                        boxShadow: `0 0 15px ${colorRgb}`,
                      }}
                    />
                    <IconComponent
                      className="h-8 w-8 p-1 rounded-full relative z-10 transition-all duration-500 group-hover:text-white group-hover:rotate-[360deg]"
                      style={{ color }}
                    />
                  </div>
                </div>
              </CardHeader>
              <CardContent className="pt-4 relative" style={{ transform: "translateZ(5px)" }}>
                <p className="text-muted-foreground">{team.description}</p>
              </CardContent>
              <CardFooter className="flex flex-wrap gap-2 pt-0 relative" style={{ transform: "translateZ(15px)" }}>
                {links.map((link, i) => (
                  <Button
                    key={i}
                    variant="outline"
                    size="sm"
                    asChild
                    className="text-xs transition-all duration-500 group-hover:shadow-md"
                    style={
                      {
                        "--hover-color": color,
                      } as React.CSSProperties
                    }
                  >
                    <a href={link.url} className="group-hover:text-[var(--hover-color)] transition-colors duration-500">
                      {link.label}
                    </a>
                  </Button>
                ))}
              </CardFooter>

              {/* Large decorative icon in the background */}
              <div
                className="absolute -bottom-12 -right-12 opacity-0 group-hover:opacity-5 transition-opacity duration-500"
                style={{ transform: "translateZ(-5px)" }}
              >
                <IconComponent className="h-40 w-40" style={{ color }} />
              </div>
            </Card>
          </div>
        )
      })}
    </div>
  )
}
