import type React from "react"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { getTeamLinks, chartColors } from "@/lib/utils"
import type { TeamPart } from "@/lib/team-data"
import type { LucideIcon } from "lucide-react"
import * as LucideIcons from "lucide-react"

interface FloatIconComboProps {
  teams: TeamPart[]
}

export default function FloatIconCombo({ teams }: FloatIconComboProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {teams.map((team, index) => {
        const IconComponent =
          (LucideIcons as Record<string, LucideIcon>)[team.icon.charAt(0).toUpperCase() + team.icon.slice(1)] ||
          LucideIcons.Briefcase

        const color = chartColors.sapphire[index % chartColors.sapphire.length]
        const links = getTeamLinks(team)

        return (
          <div key={team.name} className="group">
            <Card className="overflow-hidden transition-all duration-500 group-hover:shadow-lg relative border-2 border-transparent">
              {/* Floating particles */}
              <div className="absolute inset-0 overflow-hidden opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none">
                <div
                  className="absolute h-2 w-2 rounded-full animate-float-1"
                  style={{ backgroundColor: color, top: "20%", left: "10%" }}
                />
                <div
                  className="absolute h-3 w-3 rounded-full animate-float-2"
                  style={{ backgroundColor: color, top: "60%", left: "20%" }}
                />
                <div
                  className="absolute h-2 w-2 rounded-full animate-float-3"
                  style={{ backgroundColor: color, top: "30%", right: "15%" }}
                />
                <div
                  className="absolute h-4 w-4 rounded-full animate-float-4"
                  style={{ backgroundColor: color, bottom: "20%", right: "10%" }}
                />
              </div>

              {/* Border effect on hover */}
              <div
                className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none rounded-lg"
                style={{
                  boxShadow: `inset 0 0 0 2px ${color}`,
                }}
              />

              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-xl">{team.name}</CardTitle>
                  <div className="relative">
                    {/* Floating icon effect */}
                    <div
                      className="absolute inset-0 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-500"
                      style={{ backgroundColor: color }}
                    />
                    <IconComponent
                      className="h-8 w-8 p-1 rounded-full relative z-10 transition-all duration-500 group-hover:text-white animate-bounce-slow group-hover:animate-float-icon"
                      style={{ color }}
                    />
                  </div>
                </div>
              </CardHeader>
              <CardContent className="pt-4">
                <p className="text-muted-foreground">{team.description}</p>
              </CardContent>
              <CardFooter className="flex flex-wrap gap-2 pt-0">
                {links.map((link, i) => (
                  <Button
                    key={i}
                    variant="outline"
                    size="sm"
                    asChild
                    className="text-xs transition-all duration-500 group-hover:border-current"
                    style={
                      {
                        "--hover-color": color,
                      } as React.CSSProperties
                    }
                  >
                    <a href={link.url} className="group-hover:text-[var(--hover-color)] transition-colors duration-500">
                      {link.label}
                    </a>
                  </Button>
                ))}
              </CardFooter>
            </Card>
          </div>
        )
      })}
    </div>
  )
}
