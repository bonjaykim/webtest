import type React from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { getTeamLinks, chartColors } from "@/lib/utils"
import type { TeamPart } from "@/lib/team-data"
import type { LucideIcon } from "lucide-react"
import * as LucideIcons from "lucide-react"

interface FlipIconComboProps {
  teams: TeamPart[]
}

export default function FlipIconCombo({ teams }: FlipIconComboProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {teams.map((team, index) => {
        const IconComponent =
          (LucideIcons as Record<string, LucideIcon>)[team.icon.charAt(0).toUpperCase() + team.icon.slice(1)] ||
          LucideIcons.Briefcase

        const color = chartColors.sapphire[index % chartColors.sapphire.length]
        const gradient = chartColors.sapphireGradient[index % chartColors.sapphireGradient.length]
        const links = getTeamLinks(team)

        return (
          <div key={team.name} className="group perspective-1000 h-[250px]">
            <div
              className="relative w-full h-full transition-all duration-700 transform-gpu group-hover:rotate-y-180 preserve-3d"
              style={
                {
                  transformStyle: "preserve-3d",
                } as React.CSSProperties
              }
            >
              {/* Front of card */}
              <Card
                className="absolute inset-0 backface-hidden overflow-hidden border-2 border-transparent"
                style={
                  {
                    backfaceVisibility: "hidden",
                  } as React.CSSProperties
                }
              >
                <CardHeader className="pb-2">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-xl">{team.name}</CardTitle>
                    <div className="relative">
                      <div
                        className="p-2 rounded-full transition-all duration-500"
                        style={{ backgroundColor: `${color}20` }}
                      >
                        <IconComponent className="h-6 w-6" style={{ color }} />
                      </div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="pt-4">
                  <p className="text-muted-foreground">{team.description}</p>
                </CardContent>
              </Card>

              {/* Back of card */}
              <Card
                className="absolute inset-0 backface-hidden overflow-hidden rotate-y-180 text-white"
                style={
                  {
                    backfaceVisibility: "hidden",
                    background: gradient,
                  } as React.CSSProperties
                }
              >
                <div className="absolute top-4 right-4">
                  <div className="p-2 rounded-full bg-white/20 backdrop-blur-sm">
                    <IconComponent className="h-6 w-6 text-white animate-spin-slow" />
                  </div>
                </div>

                <div className="flex flex-col justify-center items-center h-full p-6">
                  <h3 className="text-2xl font-bold mb-4">{team.name}</h3>
                  <div className="flex flex-wrap justify-center gap-2 mb-4">
                    {links.map((link, i) => (
                      <Button
                        key={i}
                        variant="outline"
                        size="sm"
                        asChild
                        className="text-xs bg-white/10 border-white/30 text-white hover:bg-white/20"
                      >
                        <a href={link.url}>{link.label}</a>
                      </Button>
                    ))}
                  </div>
                </div>

                {/* Large decorative icon in the background */}
                <div className="absolute -bottom-8 -left-8 opacity-10">
                  <IconComponent className="h-32 w-32 text-white" />
                </div>
              </Card>
            </div>
          </div>
        )
      })}
    </div>
  )
}
