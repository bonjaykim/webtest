"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import GridCards from "./dashboard-styles/grid-cards"
import ListStyle from "./dashboard-styles/list-style"
import IconCentric from "./dashboard-styles/icon-centric"
import ChartCards from "./dashboard-styles/chart-cards"
import TabsStyle from "./dashboard-styles/tabs-style"
import AccordionStyle from "./dashboard-styles/accordion-style"
import CircleIcons from "./dashboard-styles/circle-icons"
import MinimalStyle from "./dashboard-styles/minimal-style"
import { teamData } from "@/lib/team-data"

export default function TeamDashboard() {
  const [activeTab, setActiveTab] = useState("grid")

  return (
    <div className="space-y-6">
      <Tabs defaultValue="grid" onValueChange={setActiveTab} className="w-full">
        <div className="flex justify-center mb-6">
          <TabsList className="grid grid-cols-4 md:grid-cols-8">
            <TabsTrigger value="grid">그리드</TabsTrigger>
            <TabsTrigger value="list">리스트</TabsTrigger>
            <TabsTrigger value="icon">아이콘</TabsTrigger>
            <TabsTrigger value="chart">차트</TabsTrigger>
            <TabsTrigger value="tabs">탭</TabsTrigger>
            <TabsTrigger value="accordion">아코디언</TabsTrigger>
            <TabsTrigger value="circle">원형</TabsTrigger>
            <TabsTrigger value="minimal">미니멀</TabsTrigger>
          </TabsList>
        </div>

        <TabsContent value="grid">
          <GridCards teams={teamData} />
        </TabsContent>

        <TabsContent value="list">
          <ListStyle teams={teamData} />
        </TabsContent>

        <TabsContent value="icon">
          <IconCentric teams={teamData} />
        </TabsContent>

        <TabsContent value="chart">
          <ChartCards teams={teamData} />
        </TabsContent>

        <TabsContent value="tabs">
          <TabsStyle teams={teamData} />
        </TabsContent>

        <TabsContent value="accordion">
          <AccordionStyle teams={teamData} />
        </TabsContent>

        <TabsContent value="circle">
          <CircleIcons teams={teamData} />
        </TabsContent>

        <TabsContent value="minimal">
          <MinimalStyle teams={teamData} />
        </TabsContent>
      </Tabs>
    </div>
  )
}
