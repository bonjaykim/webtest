"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import RotateIconCombo from "./combined-styles/rotate-icon-combo"
import FlipIconCombo from "./combined-styles/flip-icon-combo"
import FloatIconCombo from "./combined-styles/float-icon-combo"
import GlowIconCombo from "./combined-styles/glow-icon-combo"
import { teamData } from "@/lib/team-data"

export default function CombinedCards() {
  const [activeTab, setActiveTab] = useState("rotate-icon")

  return (
    <div className="space-y-6">
      <Tabs defaultValue="rotate-icon" onValueChange={setActiveTab} className="w-full">
        <div className="flex justify-center mb-6">
          <TabsList className="grid grid-cols-2 md:grid-cols-4">
            <TabsTrigger value="rotate-icon">회전 + 아이콘</TabsTrigger>
            <TabsTrigger value="flip-icon">플립 + 아이콘</TabsTrigger>
            <TabsTrigger value="float-icon">부유 + 아이콘</TabsTrigger>
            <TabsTrigger value="glow-icon">발광 + 아이콘</TabsTrigger>
          </TabsList>
        </div>

        <TabsContent value="rotate-icon">
          <RotateIconCombo teams={teamData} />
        </TabsContent>

        <TabsContent value="flip-icon">
          <FlipIconCombo teams={teamData} />
        </TabsContent>

        <TabsContent value="float-icon">
          <FloatIconCombo teams={teamData} />
        </TabsContent>

        <TabsContent value="glow-icon">
          <GlowIconCombo teams={teamData} />
        </TabsContent>
      </Tabs>
    </div>
  )
}
