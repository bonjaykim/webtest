import ThemeSelector from "@/components/theme-selector"

export default function ThemeSelectorPage() {
  return (
    <main className="container mx-auto p-4 md:p-8">
      <h1 className="text-3xl font-bold mb-8 text-center">테마 선택기</h1>
      <ThemeSelector />
    </main>
  )
}
