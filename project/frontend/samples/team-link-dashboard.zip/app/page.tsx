import EnhancedCards from "@/components/enhanced-cards"

export default function Home() {
  return (
    <main className="container mx-auto p-4 md:p-8">
      <h1 className="text-3xl font-bold mb-8 text-center">Sapphire 테마 팀 카드</h1>
      <EnhancedCards colorTheme="sapphire" />
    </main>
  )
}
