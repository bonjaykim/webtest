export type TeamPart = {
  name: string
  description: string
  link: string
  link1?: string
  link2?: string
  icon: string
}

export const teamData: TeamPart[] = [
  {
    name: "개발팀",
    description:
      "프론트엔드, 백엔드, 모바일 앱 개발을 담당합니다. 최신 기술 트렌드를 연구하고 적용하여 사용자 경험을 향상시키는 솔루션을 개발합니다. 애자일 방법론을 통해 빠르게 변화하는 시장 요구에 대응합니다.",
    link: "/team/dev",
    link1: "/team/dev/dev/",
    icon: "code-2",
  },
  {
    name: "디자인팀",
    description: "UI/UX 디자인과 브랜드 아이덴티티를 담당합니다.",
    link: "/team/design",
    icon: "palette",
  },
  {
    name: "마케팅팀",
    description:
      "마케팅 전략과 콘텐츠 제작을 담당합니다. 디지털 마케팅, 소셜 미디어 전략, 콘텐츠 마케팅을 통해 브랜드 인지도를 높이고 사용자 확보에 기여합니다. 데이터 기반의 마케팅 의사결정을 통해 효율적인 캠페인을 진행합니다.",
    link: "/team/marketing",
    link1: "/team/dev/marketing/",
    link2: "/team/dev/extra/",
    icon: "megaphone",
  },
  {
    name: "운영팀",
    description: "서비스 운영과 고객 지원을 담당합니다.",
    link: "/team/operations",
    link2: "/team/dev/extra/",
    icon: "settings",
  },
  {
    name: "데이터팀",
    description:
      "데이터 분석과 인사이트 도출을 담당합니다. 빅데이터 처리, 머신러닝 모델 개발, 데이터 시각화를 통해 비즈니스 의사결정을 지원하고 서비스 개선 방향을 제시합니다. 데이터 파이프라인 구축 및 관리도 담당합니다.",
    link: "/team/data",
    icon: "bar-chart-2",
  },
  {
    name: "인사팀",
    description: "인재 채용과 조직 문화를 담당합니다.",
    link: "/team/hr",
    link2: "/team/dev/extra/",
    icon: "users",
  },
]
