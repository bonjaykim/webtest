import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export const chartColors = {
  primary: [
    "hsl(215, 70%, 60%)",
    "hsl(245, 70%, 60%)",
    "hsl(275, 70%, 60%)",
    "hsl(305, 70%, 60%)",
    "hsl(335, 70%, 60%)",
    "hsl(5, 70%, 60%)",
  ],
  secondary: [
    "hsl(170, 70%, 50%)",
    "hsl(140, 70%, 50%)",
    "hsl(110, 70%, 50%)",
    "hsl(80, 70%, 50%)",
    "hsl(50, 70%, 50%)",
    "hsl(20, 70%, 50%)",
  ],
  pastel: [
    "hsl(215, 50%, 80%)",
    "hsl(245, 50%, 80%)",
    "hsl(275, 50%, 80%)",
    "hsl(305, 50%, 80%)",
    "hsl(335, 50%, 80%)",
    "hsl(5, 50%, 80%)",
  ],
  vibrant: [
    "hsl(215, 90%, 60%)",
    "hsl(245, 90%, 60%)",
    "hsl(275, 90%, 60%)",
    "hsl(305, 90%, 60%)",
    "hsl(335, 90%, 60%)",
    "hsl(5, 90%, 60%)",
  ],
  monochrome: [
    "hsl(215, 10%, 30%)",
    "hsl(215, 10%, 40%)",
    "hsl(215, 10%, 50%)",
    "hsl(215, 10%, 60%)",
    "hsl(215, 10%, 70%)",
    "hsl(215, 10%, 80%)",
  ],
  gradient: [
    "linear-gradient(135deg, hsl(215, 70%, 60%), hsl(245, 70%, 60%))",
    "linear-gradient(135deg, hsl(245, 70%, 60%), hsl(275, 70%, 60%))",
    "linear-gradient(135deg, hsl(275, 70%, 60%), hsl(305, 70%, 60%))",
    "linear-gradient(135deg, hsl(305, 70%, 60%), hsl(335, 70%, 60%))",
    "linear-gradient(135deg, hsl(335, 70%, 60%), hsl(5, 70%, 60%))",
    "linear-gradient(135deg, hsl(5, 70%, 60%), hsl(35, 70%, 60%))",
  ],
  // Sapphire 테마 색상
  sapphire: [
    "hsl(210, 80%, 45%)", // 진한 파란색
    "hsl(200, 75%, 55%)", // 중간 파란색
    "hsl(190, 70%, 60%)", // 밝은 파란색
    "hsl(180, 65%, 50%)", // 청록색
    "hsl(220, 85%, 40%)", // 남색
    "hsl(195, 80%, 65%)", // 하늘색
  ],
  // Emerald 테마 색상 (예시로 추가)
  emerald: [
    "hsl(160, 80%, 40%)", // 진한 녹색
    "hsl(150, 75%, 50%)", // 중간 녹색
    "hsl(140, 70%, 55%)", // 밝은 녹색
    "hsl(130, 65%, 45%)", // 연두색
    "hsl(170, 85%, 35%)", // 청록색
    "hsl(145, 80%, 60%)", // 라임색
  ],
  // Ruby 테마 색상 (예시로 추가)
  ruby: [
    "hsl(350, 80%, 45%)", // 진한 빨간색
    "hsl(340, 75%, 55%)", // 중간 빨간색
    "hsl(330, 70%, 60%)", // 밝은 빨간색
    "hsl(320, 65%, 50%)", // 자주색
    "hsl(0, 85%, 40%)", // 적색
    "hsl(345, 80%, 65%)", // 분홍색
  ],
  // Amber 테마 색상 (예시로 추가)
  amber: [
    "hsl(40, 80%, 45%)", // 진한 황색
    "hsl(30, 75%, 55%)", // 중간 황색
    "hsl(20, 70%, 60%)", // 밝은 황색
    "hsl(10, 65%, 50%)", // 주황색
    "hsl(50, 85%, 40%)", // 금색
    "hsl(35, 80%, 65%)", // 밝은 주황색
  ],
}

export function getTeamLinks(team: {
  link: string
  link1?: string
  link2?: string
}) {
  const links = [
    { url: team.link, label: "메인 링크" },
    ...(team.link1 ? [{ url: team.link1, label: "추가 링크 1" }] : []),
    ...(team.link2 ? [{ url: team.link2, label: "추가 링크 2" }] : []),
  ]
  return links
}

export function getRandomData(count: number): number[] {
  const data: number[] = []
  for (let i = 0; i < count; i++) {
    data.push(Math.floor(Math.random() * 100) + 20)
  }
  return data
}
