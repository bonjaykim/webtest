import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { getNotices, getRegularPosts } from "@/lib/data"
import { BellRing, Calendar, User } from "lucide-react"

export default function GridStylePage() {
  const notices = getNotices()
  const regularPosts = getRegularPosts()

  return (
    <div className="container mx-auto py-10">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">게시판 (그리드 스타일)</h1>
        <div className="space-x-2">
          <Button variant="outline" asChild>
            <Link href="/">카드 스타일</Link>
          </Button>
          <Button variant="outline" asChild>
            <Link href="/table-style">테이블 스타일</Link>
          </Button>
          <Button asChild>
            <Link href="/posts/new">새 글 작성</Link>
          </Button>
        </div>
      </div>

      {notices.length > 0 && (
        <div className="mb-8">
          <h2 className="text-xl font-semibold mb-4 flex items-center">
            <BellRing className="mr-2 h-5 w-5" />
            공지사항
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {notices.map((notice) => (
              <div
                key={notice.id}
                className="p-4 rounded-lg border-l-4 border-l-orange-500 bg-orange-50 hover:bg-orange-100 transition-colors"
              >
                <div className="flex items-center mb-2">
                  <Badge variant="outline" className="mr-2 bg-orange-100 text-orange-800 hover:bg-orange-100">
                    공지
                  </Badge>
                  <Link href={`/posts/${notice.id}`} className="font-semibold hover:underline">
                    {notice.title}
                  </Link>
                </div>
                <p className="text-sm text-muted-foreground line-clamp-2 mb-2">{notice.content}</p>
                <div className="flex justify-between text-xs text-muted-foreground">
                  <div className="flex items-center">
                    <User className="h-3 w-3 mr-1" />
                    {notice.author}
                  </div>
                  <div className="flex items-center">
                    <Calendar className="h-3 w-3 mr-1" />
                    {notice.date}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {regularPosts.map((post) => (
          <div key={post.id} className="p-6 rounded-lg border shadow-sm hover:shadow-md transition-shadow">
            <Link href={`/posts/${post.id}`} className="block">
              <h3 className="font-semibold text-lg mb-2 hover:underline">{post.title}</h3>
              <p className="text-sm text-muted-foreground line-clamp-3 mb-4">{post.content}</p>
              <div className="flex justify-between text-xs text-muted-foreground">
                <div className="flex items-center">
                  <User className="h-3 w-3 mr-1" />
                  {post.author}
                </div>
                <div className="flex items-center">
                  <Calendar className="h-3 w-3 mr-1" />
                  {post.date}
                </div>
              </div>
            </Link>
          </div>
        ))}
      </div>
    </div>
  )
}
