"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Badge } from "@/components/ui/badge"
import { getPosts } from "@/lib/data"
import Link from "next/link"
import { ChevronDown, ChevronLeft, ChevronRight, MoreHorizontal, Plus, Search } from "lucide-react"

export default function Home() {
  const allPosts = getPosts()
  const [searchTerm, setSearchTerm] = useState("")
  const [filter, setFilter] = useState<"all" | "notice" | "regular">("all")
  const [filterLabel, setFilterLabel] = useState("모든 게시글")
  const [currentPage, setCurrentPage] = useState(1)
  const postsPerPage = 10

  // 필터링 로직
  const filteredPosts = allPosts.filter((post) => {
    // 검색어 필터링
    const matchesSearch =
      post.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      post.content.toLowerCase().includes(searchTerm.toLowerCase())

    // 게시글 유형 필터링
    const matchesFilter =
      filter === "all" ? true : filter === "notice" ? post.isNotice : filter === "regular" ? !post.isNotice : true

    return matchesSearch && matchesFilter
  })

  // 페이지네이션 로직
  const totalPages = Math.ceil(filteredPosts.length / postsPerPage)
  const indexOfLastPost = currentPage * postsPerPage
  const indexOfFirstPost = indexOfLastPost - postsPerPage
  const currentPosts = filteredPosts.slice(indexOfFirstPost, indexOfLastPost)

  // 페이지 변경 핸들러
  const goToNextPage = () => {
    if (currentPage < totalPages) {
      setCurrentPage(currentPage + 1)
    }
  }

  const goToPrevPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1)
    }
  }

  // 필터 변경 핸들러
  const handleFilterChange = (value: "all" | "notice" | "regular", label: string) => {
    setFilter(value)
    setFilterLabel(label)
    setCurrentPage(1) // 필터 변경 시 첫 페이지로 이동
  }

  // 검색어 변경 핸들러
  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value)
    setCurrentPage(1) // 검색어 변경 시 첫 페이지로 이동
  }

  return (
    <div className="container mx-auto py-10">
      <div className="flex flex-col space-y-4 md:flex-row md:items-center md:justify-between md:space-y-0">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">게시판</h1>
          <p className="text-muted-foreground">최신 게시글 목록입니다. 게시글을 확인하고 관리하세요.</p>
        </div>
        <Button asChild>
          <Link href="/posts/new" className="flex items-center gap-1">
            <Plus className="h-4 w-4" /> 새 글 작성
          </Link>
        </Button>
      </div>

      <div className="mt-6 space-y-4">
        <div className="flex items-center gap-2">
          <div className="relative flex-1 md:max-w-[300px]">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input placeholder="게시글 검색..." className="h-9 pl-8" value={searchTerm} onChange={handleSearchChange} />
          </div>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="sm" className="h-9 gap-1">
                {filterLabel}
                <ChevronDown className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => handleFilterChange("all", "모든 게시글")}>모든 게시글</DropdownMenuItem>
              <DropdownMenuItem onClick={() => handleFilterChange("notice", "공지사항만")}>공지사항만</DropdownMenuItem>
              <DropdownMenuItem onClick={() => handleFilterChange("regular", "일반 게시글만")}>
                일반 게시글만
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>제목</TableHead>
                <TableHead className="w-[150px]">작성자</TableHead>
                <TableHead className="w-[150px]">작성일</TableHead>
                <TableHead className="w-[40px]"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {currentPosts.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={4} className="h-24 text-center">
                    검색 결과가 없습니다.
                  </TableCell>
                </TableRow>
              ) : (
                currentPosts.map((post) => (
                  <TableRow key={post.id}>
                    <TableCell>
                      <Link href={`/posts/${post.id}`} className="hover:underline flex items-center gap-2">
                        {post.title}
                        {post.isNotice && (
                          <Badge variant="outline" className="bg-orange-100 text-orange-800 hover:bg-orange-100">
                            공지
                          </Badge>
                        )}
                      </Link>
                    </TableCell>
                    <TableCell>{post.author}</TableCell>
                    <TableCell>{post.date}</TableCell>
                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <MoreHorizontal className="h-4 w-4" />
                            <span className="sr-only">메뉴</span>
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem>
                            <Link href={`/posts/${post.id}`} className="w-full">
                              상세보기
                            </Link>
                          </DropdownMenuItem>
                          <DropdownMenuItem>수정</DropdownMenuItem>
                          <DropdownMenuItem className="text-red-600">삭제</DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>

        <div className="flex items-center justify-between py-4">
          <div className="text-sm text-muted-foreground">
            총 <span className="font-medium">{filteredPosts.length}</span>개의 게시글 중{" "}
            <span className="font-medium">
              {indexOfFirstPost + 1}-{Math.min(indexOfLastPost, filteredPosts.length)}
            </span>
            번째 게시글
          </div>
          <div className="flex items-center space-x-2">
            <Button variant="outline" size="sm" onClick={goToPrevPage} disabled={currentPage === 1} className="gap-1">
              <ChevronLeft className="h-4 w-4" /> 이전
            </Button>
            <div className="text-sm">
              {currentPage} / {totalPages || 1}
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={goToNextPage}
              disabled={currentPage === totalPages || totalPages === 0}
              className="gap-1"
            >
              다음 <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
