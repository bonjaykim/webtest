import type React from "react"
import Link from "next/link"
import { BookOpen } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function BoardLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <div>
      {/* 네비게이션 바 */}
      <header className="border-b">
        <div className="container mx-auto py-4">
          <nav className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <BookOpen className="h-6 w-6 text-primary" />
              <span className="text-xl font-bold">커뮤니티 포털</span>
            </div>
            <div className="flex items-center gap-4">
              <Link href="/" className="text-sm font-medium hover:text-primary">
                홈
              </Link>
              <Link href="/board" className="text-sm font-medium hover:text-primary">
                게시판
              </Link>
              <Button size="sm" variant="outline">
                로그인
              </Button>
            </div>
          </nav>
        </div>
      </header>

      {children}

      {/* 푸터 */}
      <footer className="border-t mt-12">
        <div className="container mx-auto py-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center gap-2 mb-4 md:mb-0">
              <BookOpen className="h-5 w-5 text-primary" />
              <span className="font-bold">커뮤니티 포털</span>
            </div>
            <div className="text-sm text-muted-foreground">© 2024 커뮤니티 포털. All rights reserved.</div>
          </div>
        </div>
      </footer>
    </div>
  )
}
