import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import LatestPostsWidget from "@/components/latest-posts-widget"
import { BookOpen, Calendar, MessageSquare, Users } from "lucide-react"

export default function HomePage() {
  return (
    <div className="min-h-screen">
      {/* 네비게이션 바 */}
      <header className="border-b">
        <div className="container mx-auto py-4">
          <nav className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <BookOpen className="h-6 w-6 text-primary" />
              <span className="text-xl font-bold">커뮤니티 포털</span>
            </div>
            <div className="flex items-center gap-4">
              <Link href="/" className="text-sm font-medium hover:text-primary">
                홈
              </Link>
              <Link href="/board" className="text-sm font-medium hover:text-primary">
                게시판
              </Link>
              <Button size="sm" variant="outline">
                로그인
              </Button>
            </div>
          </nav>
        </div>
      </header>

      {/* 히어로 섹션 */}
      <section className="bg-gradient-to-b from-primary/10 to-background py-16">
        <div className="container mx-auto text-center">
          <h1 className="text-4xl font-bold tracking-tight mb-4">커뮤니티에 오신 것을 환영합니다</h1>
          <p className="text-muted-foreground max-w-2xl mx-auto mb-8">
            최신 정보와 유용한 팁을 공유하고, 다양한 주제에 대해 토론하는 공간입니다. 지금 바로 참여하고 다양한 정보를
            얻어가세요.
          </p>
          <div className="flex justify-center gap-4">
            <Button asChild size="lg">
              <Link href="/board">게시판 바로가기</Link>
            </Button>
            <Button variant="outline" size="lg">
              회원가입
            </Button>
          </div>
        </div>
      </section>

      {/* 메인 콘텐츠 */}
      <section className="container mx-auto py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* 메인 콘텐츠 영역 (2/3) */}
          <div className="md:col-span-2 space-y-8">
            {/* 주요 기능 소개 */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="flex items-center gap-2">
                    <MessageSquare className="h-5 w-5 text-primary" />
                    활발한 토론
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">
                    다양한 주제에 대해 의견을 나누고 새로운 아이디어를 발견하세요.
                  </p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="flex items-center gap-2">
                    <Users className="h-5 w-5 text-primary" />
                    커뮤니티 활동
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">다양한 배경을 가진 사람들과 교류하며 네트워크를 확장하세요.</p>
                </CardContent>
              </Card>
            </div>

            {/* 이벤트 섹션 */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calendar className="h-5 w-5 text-primary" />
                  다가오는 이벤트
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-start gap-4">
                    <div className="bg-primary/10 text-primary rounded-md p-2 text-center min-w-[60px]">
                      <div className="text-sm font-medium">5월</div>
                      <div className="text-xl font-bold">15</div>
                    </div>
                    <div>
                      <h3 className="font-medium">프론트엔드 개발자를 위한 성능 최적화 워크샵</h3>
                      <p className="text-sm text-muted-foreground">
                        실제 프로젝트의 성능 병목을 찾고 개선하는 방법을 실습 형태로 배우는 온라인 워크샵입니다.
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start gap-4">
                    <div className="bg-primary/10 text-primary rounded-md p-2 text-center min-w-[60px]">
                      <div className="text-sm font-medium">5월</div>
                      <div className="text-xl font-bold">22</div>
                    </div>
                    <div>
                      <h3 className="font-medium">웹 개발 트렌드 2024 웨비나</h3>
                      <p className="text-sm text-muted-foreground">
                        최신 웹 개발 트렌드와 기술에 대해 알아보는 온라인 웨비나입니다.
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* 사이드바 영역 (1/3) */}
          <div className="space-y-6">
            {/* 최신 게시글 위젯 */}
            <LatestPostsWidget />

            {/* 통계 카드 */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">커뮤니티 통계</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">총 게시글</span>
                    <span className="font-medium">25개</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">오늘 방문자</span>
                    <span className="font-medium">128명</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">회원 수</span>
                    <span className="font-medium">1,024명</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* 푸터 */}
      <footer className="border-t mt-12">
        <div className="container mx-auto py-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center gap-2 mb-4 md:mb-0">
              <BookOpen className="h-5 w-5 text-primary" />
              <span className="font-bold">커뮤니티 포털</span>
            </div>
            <div className="text-sm text-muted-foreground">© 2024 커뮤니티 포털. All rights reserved.</div>
          </div>
        </div>
      </footer>
    </div>
  )
}
