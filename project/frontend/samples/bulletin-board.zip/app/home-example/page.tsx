import LatestPostsWidget from "@/components/latest-posts-widget"

export default function HomeExamplePage() {
  return (
    <div className="container mx-auto py-10">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* 메인 콘텐츠 영역 (2/3) */}
        <div className="md:col-span-2">
          <div className="rounded-lg border p-6 h-[400px] flex items-center justify-center bg-muted/30">
            <p className="text-muted-foreground text-center">
              여기에 홈페이지 메인 콘텐츠가 들어갑니다
              <br />
              (슬라이더, 소개 등)
            </p>
          </div>
        </div>

        {/* 사이드바 영역 (1/3) - 최신 게시글 위젯 */}
        <div>
          <LatestPostsWidget />
        </div>
      </div>

      {/* 추가 콘텐츠 영역 */}
      <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-6">
        {[1, 2, 3].map((i) => (
          <div key={i} className="rounded-lg border p-6 h-[200px] flex items-center justify-center bg-muted/30">
            <p className="text-muted-foreground text-center">콘텐츠 영역 {i}</p>
          </div>
        ))}
      </div>
    </div>
  )
}
