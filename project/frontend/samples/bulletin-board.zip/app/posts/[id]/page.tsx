import Link from "next/link"
import { notFound } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { getPostById } from "@/lib/data"
import { ArrowLeft, Calendar, Edit, Trash2, User } from "lucide-react"

export default function PostPage({ params }: { params: { id: string } }) {
  const post = getPostById(Number.parseInt(params.id))

  if (!post) {
    notFound()
  }

  return (
    <div className="container mx-auto py-10">
      <div className="mb-6">
        <Button variant="ghost" size="sm" asChild className="gap-1">
          <Link href="/board">
            <ArrowLeft className="h-4 w-4" /> 목록으로 돌아가기
          </Link>
        </Button>
      </div>

      <Card>
        <CardHeader className="space-y-4">
          <div className="flex items-center justify-between">
            {post.isNotice && (
              <Badge variant="outline" className="bg-orange-100 text-orange-800 hover:bg-orange-100">
                공지사항
              </Badge>
            )}
          </div>
          <CardTitle className="text-2xl">{post.title}</CardTitle>
          <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
            <div className="flex items-center gap-1">
              <User className="h-4 w-4" />
              {post.author}
            </div>
            <div className="flex items-center gap-1">
              <Calendar className="h-4 w-4" />
              {post.date}
            </div>
            <div>조회수: 128</div>
          </div>
        </CardHeader>
        <Separator />
        <CardContent className="pt-6">
          <div className="prose max-w-none">
            {post.content.split("\n").map((paragraph, index) => (
              <p key={index}>{paragraph}</p>
            ))}
          </div>
        </CardContent>
        <Separator />
        <CardFooter className="flex justify-between py-4">
          <div className="flex gap-2">
            <Button variant="outline" size="sm" className="gap-1">
              <Edit className="h-4 w-4" /> 수정
            </Button>
            <Button variant="outline" size="sm" className="gap-1 text-red-600">
              <Trash2 className="h-4 w-4" /> 삭제
            </Button>
          </div>
          <Button variant="outline" size="sm" asChild>
            <Link href="/board">목록</Link>
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}
