import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { getNotices, getRegularPosts } from "@/lib/data"

export default function TableStylePage() {
  const notices = getNotices()
  const regularPosts = getRegularPosts()

  return (
    <div className="container mx-auto py-10">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">게시판 (테이블 스타일)</h1>
        <div className="space-x-2">
          <Button variant="outline" asChild>
            <Link href="/">카드 스타일</Link>
          </Button>
          <Button variant="outline" asChild>
            <Link href="/grid-style">그리드 스타일</Link>
          </Button>
          <Button asChild>
            <Link href="/posts/new">새 글 작성</Link>
          </Button>
        </div>
      </div>

      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-[80px]">번호</TableHead>
              <TableHead>제목</TableHead>
              <TableHead className="w-[150px]">작성자</TableHead>
              <TableHead className="w-[150px]">작성일</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {notices.map((notice) => (
              <TableRow key={notice.id} className="bg-orange-50">
                <TableCell className="font-medium">
                  <Badge variant="outline" className="bg-orange-100 text-orange-800 hover:bg-orange-100">
                    공지
                  </Badge>
                </TableCell>
                <TableCell>
                  <Link href={`/posts/${notice.id}`} className="hover:underline font-medium">
                    {notice.title}
                  </Link>
                </TableCell>
                <TableCell>{notice.author}</TableCell>
                <TableCell>{notice.date}</TableCell>
              </TableRow>
            ))}
            {regularPosts.map((post) => (
              <TableRow key={post.id}>
                <TableCell className="font-medium">{post.id}</TableCell>
                <TableCell>
                  <Link href={`/posts/${post.id}`} className="hover:underline">
                    {post.title}
                  </Link>
                </TableCell>
                <TableCell>{post.author}</TableCell>
                <TableCell>{post.date}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}
