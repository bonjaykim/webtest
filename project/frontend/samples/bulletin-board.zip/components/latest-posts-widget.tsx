import Link from "next/link"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { getPosts } from "@/lib/data"
import { ArrowRight, Calendar } from "lucide-react"

export default function LatestPostsWidget() {
  // 최신 게시글 5개만 가져오기 (날짜 기준 내림차순 정렬)
  const latestPosts = getPosts()
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    .slice(0, 5)

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-xl font-bold">최신 게시글</CardTitle>
          <Link href="/board" className="text-sm text-muted-foreground hover:text-primary flex items-center gap-1">
            전체보기 <ArrowRight className="h-3 w-3" />
          </Link>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {latestPosts.map((post) => (
            <div key={post.id} className="border-b pb-3 last:border-0 last:pb-0">
              <Link href={`/posts/${post.id}`} className="block group">
                <div className="flex items-center gap-2 mb-1">
                  <h3 className="font-medium group-hover:text-primary group-hover:underline transition-colors">
                    {post.title}
                  </h3>
                  {post.isNotice && (
                    <Badge variant="outline" className="bg-orange-100 text-orange-800 hover:bg-orange-100">
                      공지
                    </Badge>
                  )}
                </div>
                <p className="text-sm text-muted-foreground line-clamp-1 mb-1">{post.content.replace(/\n/g, " ")}</p>
                <div className="flex items-center text-xs text-muted-foreground">
                  <span className="mr-3">{post.author}</span>
                  <Calendar className="h-3 w-3 mr-1" />
                  <span>{post.date}</span>
                </div>
              </Link>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
